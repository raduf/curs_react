
import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../reducers';

import thunk from 'redux-thunk';
import reduxDevImmutable from 'redux-immutable-state-invariant';

// debug version
import {compose} from 'redux';
export default function initStore(initialState) {
    const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
    return createStore(
        rootReducer,
        initialState,
        composeEnhancers( applyMiddleware(thunk, reduxDevImmutable()) )
    )
}

// export default function initStore(initialState) {
//     return createStore(
//         rootReducer,
//         initialState,
//         applyMiddleware(thunk, reduxDevImmutable())
//     )
// }

