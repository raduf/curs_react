
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as taskActions from '../actions/taskActions';

class TaskEdit extends Component {

    constructor(props) {
        super(props);

        this.state = {
            task: { ...props.task }
        }

        this.onStatusChange = this.onStatusChange.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.task.id != nextProps.task.id) {
            this.setState({
                task: {
                    ...nextProps.task
                }
            })
        }
    }

    onStatusChange(e) {
        const status = e.target.value;
        console.log('Status: ', status);
        this.setState( {
            task: {
                ...this.state.task,
                status
            }
        })
    }

    onSubjectChange = (e) => {
        const subject = e.target.value;
        console.log('Subject: ', subject);
        this.setState( {
            task: {
                ...this.state.task,
                subject
            }
        })
    }

    onDescriptionChange = (e) => {
        const description = e.target.value;
        console.log('Description: ', description);
        this.setState( {
            task: {
                ...this.state.task,
                description
            }
        })
    }

    onSave = () => {
        console.log('Salvam task nou: ', this.state.task);
        this.props.actions.saveTask(this.state.task);
        this.props.history.push('/tasks');
    }

    render() {
        return (
            <div className="card card-inverse">
                <div className="card-block p-3">
                    <h3 className="card-title">New Task</h3>
                   
                    <div className="form-group">
                        <label htmlFor="subject">Subject</label>
                        <input 
                            value={ this.state.task.subject }
                            onChange={ this.onSubjectChange }
                            className="form-control"
                            name="subject" type="text" id="subject" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="description">Description</label>
                        <input 
                            value={ this.state.task.description }
                            onChange={ this.onDescriptionChange }
                            className="form-control" 
                            name="description" type="text" id="description" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="status">Status</label>
                        <input 
                            value={ this.state.task.status }
                            onChange={ this.onStatusChange }
                            className="form-control"
                            name="status" type="text" id="status" />
                    </div>
                    <button
                        onClick={this.onSave}
                        className="btn btn-outline-secondary">Save</button>
                </div>
            </div>
        )
    }
}

TaskEdit.propTypes = {
    task: PropTypes.object.isRequired
}

function taskById(tasks, id) {
    const task = tasks.filter( t => t.id == id);  //! folosim == pentru ca parametrul e string
    if (task) return task[0];
    return null;
}

function mapStateToProps(state, ownProps) {
    const taskId = ownProps.match.params && ownProps.match.params.id;
    let task = {
        subject: '',
        description: '',
        status: ''
    }

    if (taskId) {
        task = taskById(state.tasks, taskId) || task;
    }
    console.log('TasKEdit::mapStateToProps::taskId: ' + taskId);
    return {
        task: task
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(taskActions, dispatch)
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps  
)(TaskEdit);
