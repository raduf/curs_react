
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as taskActions from '../actions/taskActions';

class TaskNew extends Component {

    constructor(props) {
        super(props);

        this.state = {
            task: {
                code: '',
                title: '',
                description: ''
            }
        }

        this.onStatusChange = this.onStatusChange.bind(this);
    }

    onStatusChange(e) {
        const status = e.target.value;
        console.log('Status: ', status);
        this.setState( {
            task: {
                ...this.state.task,
                status
            }
        })
    }

    onSubjectChange = (e) => {
        const subject = e.target.value;
        console.log('Subject: ', subject);
        this.setState( {
            task: {
                ...this.state.task,
                subject
            }
        })
    }

    onDescriptionChange = (e) => {
        const description = e.target.value;
        console.log('Description: ', description);
        this.setState( {
            task: {
                ...this.state.task,
                description
            }
        })
    }

    onSave = () => {
        console.log('Salvam task nou: ', this.state.task);
        // this.props.addTask(this.state.task);
        // this.props.addTask(this.state.task); // la fel pentru a doua varianta

        this.props.actions.addTask(this.state.task);
    }

    render() {
        return (
            <div className="card card-inverse">
                <div className="card-block p-3">
                    <h3 className="card-title">New Task</h3>
                   
                    <div className="form-group">
                        <label htmlFor="subject">Subject</label>
                        <input 
                            value={ this.state.task.subject }
                            onChange={ this.onSubjectChange }
                            className="form-control"
                            name="subject" type="text" id="subject" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="description">Description</label>
                        <input 
                            value={ this.state.task.description }
                            onChange={ this.onDescriptionChange }
                            className="form-control" 
                            name="description" type="text" id="description" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="status">Status</label>
                        <input 
                            value={ this.state.task.status }
                            onChange={ this.onStatusChange }
                            className="form-control"
                            name="status" type="text" id="status" />
                    </div>
                    <button
                        onClick={this.onSave}
                        className="btn btn-outline-secondary">Save</button>
                </div>
            </div>
        )
    }
}

TaskNew.propTypes = {
    tasks: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
}

function mapStateToProps(state, ownProps) {
    return {
        tasks: state.tasks
    }
}

// daca nu implementam mapDispatchToProps, Redux ataseaza o metoda dispatch() pe props
function mapDispatchToProps(dispatch) {
    return {
        // addTask: task => dispatch( taskActions.addTask(task) )
        // addTask: bindActionCreators(taskActions.addTask, dispatch) // varianta la prima

        actions: bindActionCreators(taskActions, dispatch)
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps  
)(TaskNew);
