import React from 'react';
import { Link } from 'react-router-dom';

const TaskList = (props) => {
    return (
        <div className="row">
            <div className="mt-2 w-100">
                <h3>Tasks</h3>
                <table className="table table-inverse">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Owner</th>
                            <th>Deadline</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th>Total items: {props.tasks.length} </th>
                        </tr>
                    </tfoot>
                    <tbody>
                    {   props.tasks && 
                        props.tasks.map( (task, index) => 
                            <tr key={task.id}>
                                <td><Link to={'/tasks/edit/' + task.id}>{task.subject}</Link></td>
                                <td>{task.description}</td>
                                <td>{task.status}</td>
                                <td>{task.owner_name}</td>
                                <td>{task.end_date && task.end_date.substring(0,10)}</td>
                            </tr>
                        )
                    }
                    </tbody>
                </table>
            </div>
        </div>

    )
}

export default TaskList;
