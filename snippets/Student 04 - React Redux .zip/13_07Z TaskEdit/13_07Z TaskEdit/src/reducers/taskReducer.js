import * as types from '../actions/actionTypes';

export default function taskReducer(state = [], action) {
    switch (action.type) {
        case types.ADD_TASK:
            return [...state, {
                ...action.task
            }]

        case types.GET_TASKS_SUCCESS:
            return action.tasks

        case types.CREATE_TASKS_SUCCESS:
            return [
                ...state,
                { ...action.task }
            ] 

        case types.UPDATE_TASKS_SUCCESS:
            return [
                ...state.filter( task => task.id != action.task.id),
                { ...action.task }
            ]

        default:
            return state;
    }
}
