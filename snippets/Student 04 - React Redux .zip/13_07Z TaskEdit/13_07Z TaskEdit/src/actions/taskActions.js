import * as types from './actionTypes';
import axios from 'axios';

export function addTask(task) {
  return {
    type: types.ADD_TASK,
    task 
  }
}

export function getTasksSuccess(tasks) {
  return {
    type: types.GET_TASKS_SUCCESS,
    tasks 
  }
}

export function updateTaskSuccess(task) {
  console.log('Creating action UPDATE_TASKS_SUCCESS')
  return {
    type: types.UPDATE_TASKS_SUCCESS,
    task 
  }
}

export function createTaskSuccess(task) {
  console.log('Creating action CREATE_TASKS_SUCCESS')
  return {
    type: types.CREATE_TASKS_SUCCESS,
    task 
  }
}

export function getTasks() {
  return function(dispatch) {
    return axios.get('http://localhost:3000/tasks')
      .then( response => { dispatch(getTasksSuccess(response.data)) } )
      .catch( (error) => console.log(error) )
  }
}

export function saveTask(task) {
  console.log('Action::saveTask: ', task);
  return function(dispatch, getState) {   // parametru optional getState in caz ca avem nevoie
    
    // daca exista id avem update
    if (task.id)
      return axios.put('http://localhost:3000/tasks/' + task.id, task)
        .then( response => { dispatch(updateTaskSuccess(response.data)) })
        .catch( (error) => console.log(error) )

    // daca nu avem id este un task nou
    return axios.post('http://localhost:3000/tasks', task)
        .then( response => { dispatch(createTaskSuccess(response.data)) })
        .catch( (error) => console.log(error) )
    
  }
}

