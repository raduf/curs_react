import * as types from './actionTypes';
import axios from 'axios';

export function addTask(task) {
  return {
    type: types.ADD_TASK,
    task 
  }
}

export function getTasksSuccess(tasks) {
  return {
    type: types.GET_TASKS_SUCCESS,
    tasks 
  }
}

export function getTasks() {
  return function(dispatch) {
    return axios.get('http://localhost:3000/tasks')
      .then( response => { dispatch(getTasksSuccess(response.data)) } )
      .catch( (error) => console.log(error) )
  }
}

