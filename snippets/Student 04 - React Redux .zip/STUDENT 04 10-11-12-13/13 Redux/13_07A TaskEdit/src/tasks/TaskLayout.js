import React, { Component } from 'react';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as taskActions from '../actions/taskActions';

import { Switch, Route, NavLink } from 'react-router-dom';
import TaskList from './TaskList';
import TaskNew from './TaskNew';

class TaskLayout extends Component  {

    constructor(props) {
        super(props);

        this.match = this.props.match;
    }

    render() {
        return (
                <div className="container">
                    <div className="row">
                        <h4 className="mt-4 ml-3">Tasks</h4>
                    </div>
                    <div className="row">
                        <div className="col-md-3 mt-2">
                            <NavLink exact to={`${this.match.url}`}  activeClassName="active"
                                className="btn btn-block btn-outline-info">All tasks</NavLink>
                            <NavLink exact to={`${this.match.url}/new`}  activeClassName="active"
                                className="btn btn-block btn-outline-info">New task</NavLink>
                            <hr />
                            <h5>Owner / Asignee:</h5>
                            <button className="btn btn-block btn-outline-info">FOR Me</button>
                            <button className="btn btn-block btn-outline-info">BY Me</button>
                            <hr />
                            <h5>Status:</h5>
                            <button className="btn btn-block btn-outline-info">New</button>
                            <button className="btn btn-block btn-outline-info">Working</button>
                            <button className="btn btn-block btn-outline-info">Closed</button>
                        </div>
                        <div className="col-md-9">
                            <Switch>
                                <Route exact path={`${this.match.url}`} 
                                    render={ () => (
                                        <TaskList {...this.props} tasks={this.props.tasks} />
                                )} />
                                <Route path={`${this.match.url}/new`} component={TaskNew}/>
                            </Switch>
                        </div>
                    </div>
                </div>
        )
    }
}

function mapStateToProps(state, ownProps) {
    return {
        tasks: state.tasks
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(taskActions, dispatch)
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps  
)(TaskLayout);

