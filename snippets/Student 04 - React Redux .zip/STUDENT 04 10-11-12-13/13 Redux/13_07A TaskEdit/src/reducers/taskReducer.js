import * as types from '../actions/actionTypes';

export default function taskReducer(state = [], action) {
    switch (action.type) {
        case types.ADD_TASK:
            return [...state, {
                ...action.task
            }]

        case types.GET_TASKS_SUCCESS:
            return action.tasks

        default:
            return state;
    }
}
