```js

<div className="card card-inverse">
    <div className="card-block p-3">
        <h3 className="card-title">New Task</h3>

        <div className="form-group">
            <label htmlFor="code">Code</label>
            <input 
                className="form-control"
                name="code" type="text" id="code" />
        </div>
        <div className="form-group">
            <label htmlFor="name">Name</label>
            <input 
                className="form-control"
                name="name" type="text" id="name" />
        </div>
        <div className="form-group">
            <label htmlFor="description">Description</label>
            <input 
                className="form-control" 
                name="description" type="text" id="description" />
        </div>
        <button
            className="btn btn-outline-secondary">Save</button>

    </div>
</div>

```