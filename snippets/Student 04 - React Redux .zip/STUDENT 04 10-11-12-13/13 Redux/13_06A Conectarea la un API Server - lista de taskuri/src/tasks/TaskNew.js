
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as taskActions from '../actions/taskActions';

class TaskNew extends Component {

    constructor(props) {
        super(props);

        this.state = {
            task: {
                code: '',
                title: '',
                description: ''
            }
        }

        this.onCodeChange = this.onCodeChange.bind(this);
    }

    onCodeChange(e) {
        const code = e.target.value;
        console.log('Code: ', code);
        this.setState( {
            task: {
                ...this.state.task,
                code
            }
        })
    }

    onTitleChange = (e) => {
        const title = e.target.value;
        console.log('Title: ', title);
        this.setState( {
            task: {
                ...this.state.task,
                title
            }
        })
    }

    onDescriptionChange = (e) => {
        const description = e.target.value;
        console.log('Description: ', description);
        this.setState( {
            task: {
                ...this.state.task,
                description
            }
        })
    }

    onSave = () => {
        console.log('Salvam task nou: ', this.state.task);
        // this.props.addTask(this.state.task);
        // this.props.addTask(this.state.task); // la fel pentru a doua varianta

        this.props.actions.addTask(this.state.task);
    }

    render() {
        return (
            <div className="card card-inverse">
                <div className="card-block p-3">
                    <h3 className="card-title">New Task</h3>
                    <div className="form-group">
                        <label htmlFor="code">Code</label>
                        <input 
                            value={ this.state.task.code }
                            onChange={ this.onCodeChange }
                            className="form-control"
                            name="code" type="text" id="code" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="title">Title</label>
                        <input 
                            value={ this.state.task.title }
                            onChange={ this.onTitleChange }
                            className="form-control"
                            name="title" type="text" id="title" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="description">Description</label>
                        <input 
                            value={ this.state.task.description }
                            onChange={ this.onDescriptionChange }
                            className="form-control" 
                            name="description" type="text" id="description" />
                    </div>
                    <button
                        onClick={this.onSave}
                        className="btn btn-outline-secondary">Save</button>
                </div>
                { this.props.tasks && 
                    this.props.tasks.map( (task, idx) => 
                        <p key={idx}>{task.code} - {task.title} - {task.description} </p>
                    )
                }
            </div>
        )
    }
}

TaskNew.propTypes = {
    tasks: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
}

function mapStateToProps(state, ownProps) {
    return {
        tasks: state.tasks
    }
}

// daca nu implementam mapDispatchToProps, Redux ataseaza o metoda dispatch() pe props
function mapDispatchToProps(dispatch) {
    return {
        // addTask: task => dispatch( taskActions.addTask(task) )
        // addTask: bindActionCreators(taskActions.addTask, dispatch) // varianta la prima

        actions: bindActionCreators(taskActions, dispatch)
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps  
)(TaskNew);
