import * as types from './actionTypes';

export function addTask(task) {
  return {
    type: types.ADD_TASK,
    task 
  }
}
