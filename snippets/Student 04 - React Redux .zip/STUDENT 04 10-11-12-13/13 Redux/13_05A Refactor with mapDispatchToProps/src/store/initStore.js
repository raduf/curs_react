
import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../reducers';

import reduxDevImmutable from 'redux-immutable-state-invariant';

export default function initStore(initialState) {
    return createStore(
        rootReducer,
        initialState,
        applyMiddleware(reduxDevImmutable())
    )
}

