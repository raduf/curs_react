import React from 'react';
import ReactDOM from 'react-dom';

import initStore from './store/initStore';
import { Provider } from 'react-redux'

import { BrowserRouter } from 'react-router-dom';
import './index.css';
import 'bootstrap/dist/css/bootstrap.css';
import App from './App';

const store = initStore();

ReactDOM.render((
    <Provider store={store}>
        <BrowserRouter> 
            <App />
        </BrowserRouter>
    </Provider>
), document.getElementById('root'));
