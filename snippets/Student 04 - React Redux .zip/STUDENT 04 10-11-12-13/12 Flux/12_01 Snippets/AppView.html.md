```js

function Main(props) {
  return (
    <section id="main">
      <ul id="task-list">
      ...

          <li key={task.id}>
            <div className="view">
              <input
                className="toggle"
                type="checkbox"
              />
              <label>{task.text}</label>
              <button
                className="destroy"
              />
            </div>
          </li>

      </ul>
    </section>
  );
}


```

> Header
```js

      <header id="header">
        <h1>Tasks</h1>
      </header>

```

> Footer
```js

      <footer id="footer">
        <span id="task-count">
          <strong>
            {numar task-uri} 
          </strong>
          
        </span>
      </footer>

```