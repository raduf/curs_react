
'use strict';

import React from 'react';
import ReactDOM from 'react-dom'; 


ReactDOM.render(<div>Simple Task Manager</div>, document.getElementById('app'));
