
'use strict';

import React from 'react';
import ReactDOM from 'react-dom'; 
import AppContainer from './containers/AppContainer';


ReactDOM.render(<AppContainer />, document.getElementById('app'));

// Test data
import TaskActions from './data/TaskActions';

TaskActions.addTask('Create website structure');
TaskActions.addTask('Add Home page');
TaskActions.addTask('Update About page');
