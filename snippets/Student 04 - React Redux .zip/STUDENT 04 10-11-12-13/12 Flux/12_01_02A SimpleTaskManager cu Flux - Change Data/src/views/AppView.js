
import React from 'react';

function AppView(props) {
    return (
        <div>
          <Header {...props} />
          <Main {...props} />
          <Footer {...props} />
        </div>
      );
}

function Header(props) {
    return (
      <header id="header">
        <h1>Tasks Manager</h1>
      </header>
    );
  }

  function Footer(props) {
    if (props.tasks.size === 0) {
      return null;
    }
    return (
      <footer id="footer">
        <span id="task-count">
          <strong>
            {props.tasks.size}
          </strong>
          {' tasks'}
        </span>
      </footer>
    );
  }

  function Main(props) {
    if (props.tasks.size === 0) {
      return null;
    }
    return (
      <section id="main">
        <ul id="task-list">
          {[...props.tasks.values()].reverse().map(task => (
            <li key={task.id}>
              <div className="view">
                <input
                  className="toggle"
                  type="checkbox"
                  checked={task.complete}
                  onChange={ () => {} }
                />
                <label>{task.subject}</label>
                <button
                  className="destroy"
                  onClick={ () => {} }
                />
              </div>
            </li>
          ))}
        </ul>
      </section>
    );
  }


export default AppView;
