
import Immutable from 'immutable';

const Task = Immutable.Record({
  id: '',
  subject: '',
  description: '',
  complete: false,
});

export default Task;
