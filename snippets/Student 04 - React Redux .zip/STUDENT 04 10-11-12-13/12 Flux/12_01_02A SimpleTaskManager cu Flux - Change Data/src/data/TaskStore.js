
import Immutable from 'immutable';
import { ReduceStore } from 'flux/utils';
import Counter from '../counter';
import Task from './Task';
import TaskActionTypes from './TaskActionTypes';
import TaskDispatcher from './TaskDispatcher';

class TaskStore extends ReduceStore {
  constructor() {
    super(TaskDispatcher);
  }

  getInitialState() {
    return Immutable.OrderedMap();
  }

  reduce(state, action) {
    switch (action.type) {
      case TaskActionTypes.ADD_TASK:
        // ...
        if (!action.subject) { return state }

        const id = Counter.increment();
        
        return state.set(id, new Task({
            id,
            subject: action.subject,
            complete: false,
        }));
        // return state;

      default:
        return state;
    }
  }
}

export default new TaskStore();
