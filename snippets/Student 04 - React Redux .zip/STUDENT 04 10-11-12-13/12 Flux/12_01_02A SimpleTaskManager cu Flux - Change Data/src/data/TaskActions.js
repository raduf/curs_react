
import TaskActionTypes from './TaskActionTypes';
import TaskDispatcher from './TaskDispatcher';

const Actions = {
  addTask(subject) {
    TaskDispatcher.dispatch({
      type: TaskActionTypes.ADD_TASK,
      subject,
    });
  },
};

export default Actions;
