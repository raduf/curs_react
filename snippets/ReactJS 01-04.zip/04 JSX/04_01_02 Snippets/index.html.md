```html

<!DOCTYPE HTML>
<html>
    <head>
        <meta charset = "utf-8">
        <title></title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" >

    </head>
    <body>
        <div id="main"></div>
    </body>
</html>

```