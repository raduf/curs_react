```html

<!DOCTYPE HTML>
<html>
    <head>
        <meta charset = "utf-8">
        <title></title>
    </head>
    <body>
        <div id="main"></div>
    </body>
</html>

```