```html

    <div className="col-8 pt-2">
        <form>
            <div className="form-group">
                <label htmlFor="name">Name</label>
                <input name="name" type="text" className="form-control" id="name" />
            </div>
            <div className="form-group">
                <label htmlFor="code">Code</label>
                <input name="code" type="text" className="form-control" id="code" />
            </div>
            <div className="form-group">
                <label htmlFor="description">Description</label>
                <input name="description" type="text" className="form-control" id="description" />
            </div>
            <button className="btn btn-success">Save</button>
        </form>
    </div>

```