```html
        <div className="row justify-content-center">
            <div className="card mt-2" style={{width: "20rem"}}>
                <div className="card-body">
                <h4 className="card-title">Card title</h4>
                <h6 className="card-subtitle mb-2 text-muted">Card subtitle</h6>
                <p className="card-text">
                    Card Body
                </p>
                </div>
            </div>
        </div>

```

