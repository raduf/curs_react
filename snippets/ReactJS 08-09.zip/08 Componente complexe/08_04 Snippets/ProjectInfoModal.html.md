```html
    <div className="card" style={{height: "100%"}}>
        <div className="card-body">
            <h4 className="card-title">Project name</h4>
            <h6 className="card-subtitle mb-2 text-muted">Project code</h6>
            <p className="card-text">Project Description</p>
        </div>
        <div className="card-footer">
            <button className="btn btn-info btn-sm"> Close </button>
        </div>
    </div>
```