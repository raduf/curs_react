```html

<nav className="navbar navbar-expand navbar-dark bg-primary text-white  justify-content-between">
  <a className="navbar-brand">Simple Project Manager</a>
  
  <ul className="navbar-nav">
      <li className="nav-item active">
        <a className="nav-link">Dashboard</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" >Projects</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" >Profile</a>
      </li>
      <li className="nav-item">
        <a className="nav-link disabled">James Hansen</a>
      </li>
    </ul>
</nav>

```
