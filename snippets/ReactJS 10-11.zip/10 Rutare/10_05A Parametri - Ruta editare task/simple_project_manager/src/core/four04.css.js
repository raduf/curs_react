
export const linkList = {
    paddingTop: '0.5rem',
    paddingBottom: '0.5rem',
    color: 'white',
    backgroundColor: '#007bff'
}

