==============================================================================
Pornire Server API:
## Cerinte:
server api: json-server -d 100 db.json     (ruleaza comanda in folderul apiserver)
(serverul de api se deschide pe portul 3000)
sunt disponibile resursele:
    http://localhost:3000/projects
    http://localhost:3000/tasks
    http://localhost:3000/statuses
    http://localhost:3000/users
    http://localhost:3000/categories
    
==============================================================================    

## npm install -g json-server

