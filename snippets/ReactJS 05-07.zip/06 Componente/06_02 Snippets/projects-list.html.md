```html

    <div className="row justify-content-center"> 
        <div className="col-8 pt-2">
            <div className="card card-inverse card-outline-default text-white"
                    style={ {"backgroundColor": "#555", "borderColor": "#555"} }>
                <h4 className="card-header">
                    DENUMIRE PROIECT
                    <span className="float-right badge badge-default">
                        COD
                    </span>
                </h4>
                <div className="card-text pt-2 pb-2 pl-4 pr-4">Descriere Proiect</div>
            </div>
        </div>
    </div>


```
