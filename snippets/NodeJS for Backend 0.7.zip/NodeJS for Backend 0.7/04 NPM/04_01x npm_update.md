
# 04_01Z_npm_update

---

## verificam versiunile pentru lodash si moment


`npm view lodash versions`
`npm view moment versions`

---

## instalam lodash si moment versiuni anterioare

- moment va fi alt `major`

```
npm install lodash@4.17.2
npm install moment@1.6.2
```

---

## verificam ce versiuni avem instalate

`npm list --depth=0`

```
+-- lodash@4.17.2
`-- moment@1.6.2
```

---

## verificam pachetele vechi

`npm outdated`

```js
Package  Current   Wanted   Latest  Location
lodash    4.17.2  4.17.10  4.17.10  04_01Z_npm_update
moment     1.6.2    1.7.2   2.22.1  04_01Z_npm_update
```

- `wanted` inseamna ce ne permite `^`
- observam ca moment are un nou `major`


---

## actualizam pachetele non breaking

`npm update`

```
+ moment@1.7.2
+ lodash@4.17.10
```

- observam ca moment nu a trecut la urmatorul `major`
- dar s-a actualizat la ultimul `minor` disponibil

`npm outdated`
```
Package  Current  Wanted  Latest  Location
moment     1.7.2   1.7.2  2.22.1  04_01Z_npm_update
```

---

## actualizarea versiunilor `major`


`npm install -g npm-check-updates`

```
+ npm-check-updates@2.14.2
```

- verificam actualizarile vizate

`npm-check-updates`

```
moment  ^1.7.2  →  ^2.22.1

Run ncu with -u to upgrade package.json
```

- actualizam `major`

`npm-check-updates -u`

```
[INFO]: You can also use ncu as an alias

moment  ^1.7.2  →  ^2.22.1

```

- acum s-a actualizat package.json nu s-a si instalat pachetul

- verificam `package.json` 

```
  "dependencies": {
    "lodash": "^4.17.10",
    "moment": "^2.22.1"
  }
```

- `package.json` este actualizat, acum putem instala pachetele

`npm install`

- verificam daca mai avem pachete cu versiuni vechi

`npm outdated` sau `ncu`

```
All dependencies match the latest package versions :)
```

