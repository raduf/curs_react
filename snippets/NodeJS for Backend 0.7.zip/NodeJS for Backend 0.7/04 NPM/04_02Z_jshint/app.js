
const myvar = 100;
myvar = 200;

let a = 100
let b = 200

if (a == b) console.log('Sunt egale...')

console.log(myvar);
