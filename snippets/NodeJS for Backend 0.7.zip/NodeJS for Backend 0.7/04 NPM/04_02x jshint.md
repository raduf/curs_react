
# Development Dependencies

- vom instala si utiliza `jshint`
    - nu este nevoie de el in productie

---

## Instalare `jshint`

`npm install`

`npm i jshint --save-dev`

- observam `package.json`

```json
// package.json

{
  "name": "04_02Z_jshint",
  ...
  "dependencies": {
    "lodash": "^4.17.10",
    "moment": "^2.22.1"
  },
  "devDependencies": {
    "jshint": "^2.9.5"
  }
}

```

- toate dependentele sunt instalate in acelasi folder: `node_modules`

- doar in `package.json` sunt separate


---

## testarea jshint

- cream un script in `package.json`

```json
// package.json

  "scripts": {
    "jshint": "jshint app.js"
  },
  ...

```


- configuram jshint
  - poate fi configurat cu argumentul `--config`
    - `jshint --config ../path/to/my/config.json`
  - poate fi configurat adaugand proprietatea `jshintConfig` in `package.json`
  - poate fi configurat prin crearea unui fisier special
    - `.jshintrc` (in folderul curent sau in parinte)


```json
// .jshintrc

{
    "esversion": 6,
    "curly": true,
    "eqeqeq": true,
    "nocomma": true
}

```


- scriem cod care genereaza erori si warning-uri

```js
// app.js

const myvar = 100;
myvar = 200;

let a = 100
let b = 200

if (a == b) console.log('Sunt egale...')

console.log(myvar);


```


- executam comanda

`npm run jshint`

```
> jshint app.js

app.js: line 5, col 12, Missing semicolon.
app.js: line 6, col 12, Missing semicolon.
app.js: line 8, col 9, Expected '===' and instead saw '=='.
app.js: line 8, col 13, Expected '{' and instead saw 'console'.
app.js: line 8, col 41, Missing semicolon.
app.js: line 3, col 1, Attempting to override 'myvar' which is a constant.

6 errors
```

