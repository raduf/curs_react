###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Webpack Crash Course

## Introduction

JavaScript module bundling has been around for a while. RequireJS had its first commits in 2009, then Browserify made its debut, and since then several other bundlers have spawned across the Internet. Among that group, webpack has jumped out as one of the best.

### What is Module Bundling?

Module Bundling simply means that you can separate your source code into multiple files and import those files into your application to use the functionality contained in them. This wasn’t built into browsers, so module bundlers were built to bring this capability in a couple forms: by asynchronously loading modules and running them when they have finished loading, or by combining all of the necessary files into a single JavaScript file that would be loaded via a `<script>` tag in the HTML.

Module bundling is important and is pragmatically useful for web applications for the following reasons.

* You need to keep track of the proper order in which the files should load, including which files depend on which other files and making sure not to include any files you don’t need.
* Multiple `<script>` tags means multiple calls to the server to load all of your code, which is worse for performance.
* Obviously, this entails a lot of manual work, instead of letting the computer do it for you.

## What is Webpack?

Webpack is a popular module bundler, a tool for bundling application source code in convenient chunks and for loading that code from a server into a browser. It takes in various assets, such as JavaScript, CSS, and HTML, and then transforms these assets into a format that’s convenient to consume through a browser. Doing this well takes away a significant amount of pain from web development. It is based on a configure-driven approach and takes all your assets in the project as dependencies. It treats the complete project as a dependency graph. The file `index.js` in your project that pulls in the dependencies the project needs through the standard require or import statements.

Webpack roams over your application source code, looking for import statements, building a dependency graph, and emitting one or more bundles. With plugins and rules, Webpack can preprocess and minify different non-JavaScript files such as TypeScript, SASS, and LESS files.

### Getting Started

Before we can use webpack, we need to install it. To do that, we’re going to need Node.js and npm. To get a starting point, you should create a directory for the project and set up a package.json there. npm uses that to manage project dependencies. Here are the basic commands:

```shell
mkdir webpack-demo
cd webpack-demo
npm init -y # -y generates *package.json*, skip for more control
```

To add webpack to the project, execute:

```shell
npm install webpack webpack-cli --save-dev # -D to type less
```

You should see webpack at your package.json devDependencies section after this. You determine what Webpack does and how it does it with a JavaScript configuration file. Create a new file named `webpack.config.js` in your project’s root directory. This is the file name that webpack will look for by default, but you can pass the –config [filename] option to webpack if you want to name your configuration file something else or to put it in a different directory.

```javascript
const webpack = require('webpack')
const path = require('path')

entry: {
  context: path.resolve(__dirname, 'src'),
  'app': './src/main.ts'
},
```

Webpack inspects that file and traverses its import dependencies recursively. The file `src/main.ts`:

```javascript
import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {}
```

It sees that you're importing `@angular/core` so it adds that to its dependency list for potential inclusion in the bundle. It opens the `@angular/core` file and follows its network of import statements until it has built the complete dependency graph from `main.ts` down.

Then it outputs these files to the `bundle.js` bundle file designated in configuration, `webpack.config.js`:

```javascript
// webpack.config.js
const webpack = require('webpack');
const path = require('path');

module.exports = {
  context: path.resolve(__dirname, 'src'),
  entry: {
    app: './app.js'
  },
  resolve: {
    extensions: ['.ts', '.js']
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'bundle.js'
  },
  module: {
    rules: [
      {
        test: /\.ts$/,
        loaders: [
          {
            loader: 'awesome-typescript-loader'
          },
          'angular2-template-loader'
        ]
      },
      {
        test: /\.js$/,
        include: path.resolve(__dirname, 'src'),
        use: [
          {
            loader: 'babel-loader',
            options: {
              presets: [['es2015', { modules: false }]]
            }
          }
        ]
      }
    ]
  }
};
```

The config above is a common starting point, it instructs webpack to compile our entry point src/app.js into our output /dist/bundle.js and all .js files will be transpiled from ES2015 to ES5 with Babel. To get this running we’re going to need to install five packages, `awesome-typescript-loader` to load and render typescript files, `angular2-template-loader` to load all inlines all html and style's in angular2 components, `babel-core`, the webpack loader `babel-loader` and the preset `babel-preset-es2015` for the flavor of JavaScript we want to write. `{ modules: false }` enables Tree Shaking to remove unused exports from your bundle to bring down the file size.

```shell
npm install babel-core babel-loader babel-preset-es2015 angular2-template-loader awesome-typescript-loader --save-dev
```

Also notice the keywords, `entry`, `resolve`, and `module.rules`.

* entry—the entry-point files that define the bundles.
* resolve—how to resolve file names when they lack extensions.
* module.rules— module is an object with rules for deciding how files are loaded.

Lastly, replace the scripts section of package.json with the following:

```json
"scripts": {
  "start": "webpack --watch",
  "build": "webpack -p"
},
```

Whenever you make a change, the webpack command should now automatically rerun. This is what `--watch` flag does for us. Open up `dist/bundle.js` to see what webpack has done, at the top is webpack’s module bootstrapping code and right at the bottom is our module.

## Loaders

### Loading Styles

We have already discussed about `awesome-typescript-loader`, and `babel-loader` in the previous section. Loaders basically tell webpack what to do when it encounters imports for different file types. You can chain loaders together into a series of transforms. Let us take a deeper look in this process by importing a separate loader for CSS. Whenever we need to add a loader to our webpack config file, the first step is to install required dependencies:

```shell
npm install css-loader style-loader sass-loader node-sass --save-dev
```

Second step is to add a rule to the same config file. In this case, we are adding a rule to read `.scss` files.

```javascript
// webpack.config.js
rules: [
  {
    test: /\.scss$/,
    use: ['style-loader', 'css-loader', 'sass-loader']
  }
];
```

Notice the array in above case. The array of loaders is processed in reverse order.

* sass-loader transforms Sass into CSS.
* css-loader parses the CSS into JavaScript and resolves any dependencies.
* style-loader outputs our CSS into a `<style>` tag in the document.

Let us add a Sass source file in our project:

```scss
/* src/style.scss */
$bluegrey: #2b3a42;

pre {
  padding: 20px;
  background: $bluegrey;
  color: #dedede;
  text-shadow: 0 1px 1px rgba(#000, 0.5);
}
```

You can now require Sass directly from your JavaScript, import it from the top of `app.js`.

```javascript
// src/app.js
import './style.scss';
```

We do not have to reload the project from our server end since webpack is watching for any file changes. If we reload the web page in our browser we can see the changes we recently added to our application. Webpack supports a large variety of formats compiling to CSS through loaders. Similarly, like above you can add loaders for Less and Stylus.

### Loading Order

It's good to keep in mind that webpack's loaders are always evaluated from right to left and from bottom to top (separate definitions). The right-to-left rule is easier to remember when you think about as functions. We have seen an example of this our webpack config in the previous section. However, there can be rare scenarios, when we want to enforce specific rules to be applied before the regular ones. In this case, we can use the keyword `enforce`. It can be set to either pre or post to push processing either before or after other loaders.

```javascript
{
  // Conditions
  test: /\.js$/,
  enforce: "pre", // "post" too

  // Actions
  use: "eslint-loader",
},
```

Linting is a good example because the build should fail before it does anything else if it does not pass linting rules. Using enforce: `post` is rarer and it would imply you want to perform a check against the built source. Performing analysis against the built source is one potential example.

### Loading Image Assets

Static assets such as images can be easily configured for the webpack to load. A web application can be made slow by loading a lot of small assets as each request comes with an overhead. `file-loader` outputs image files and returns paths to them instead of inlining. This technique works with other assets types, such as fonts. We as usual, install the dependency:

```shell
npm install file-loader --save-dev
```

The configuration part will be done in `webpack.config.js`:

```javascript
{
  test: /\.(jpg|png|svg)$/,
  use: {
    loader: "file-loader"
  },
},
```

`file-loader` is also the easiest way to load and work with svg images in your Angular web application. After adding the above configuration all you have to do is refer to svg files as below.

```scss
.icon {
  background-image: url('../assets/icon.svg');
}
```

Alternative to `file-loader` and just for loading svg image files is `svg-url-loader`. In case you want to compress your images, use image-webpack-loader, svgo-loader (SVG specific), or imagemin-webpack-plugin. Compression is particularly valuable for production builds as it decreases the amount of bandwidth required to download your image assets and speed up your site or application as a result.

### Loading Fonts

Loading fonts is similar to loading images. It does come with unique challenges, though. How to know what font formats to support? There can be up to four font formats to worry about if you want to provide first class support to each browser.

The problem can be solved by deciding a set of browsers and platforms that should receive first class service. The rest can use system fonts. We will use `file-loader` again, just like in images, to load the fonts.

```javascript
{
  test: /\.(ttf|eot|woff|woff2)$/,
  loader: "file-loader",
  options: {
    name: "fonts/[name].[ext]",
  },
},
```

The above snippet showcases how to support mutliple formats at the same time. This type of configuration can be isomorphic and work with different projects. In a similar manner you can use google fonts directly in your application by installing `google-fonts-webpack-plugin` package.

## Plugins

Plugins are the way, other than loaders, to install custom functionality into webpack. You have much more freedom to add them to the webpack workflow because they aren’t limited to being used only while loading specific file types; they can be injected practically anywhere and are, therefore, able to do much more.

The first plugin we’ll use is HTML Webpack Plugin, which simply generates an HTML file for us — we can finally start using the web. First, we need to install the plugin: `npm i -D html-webpack-plugin`. When that’s done, we need to hop into webpack.config.js and add some changes.

```javascript
const HtmlwebpackPlugin = require('html-webpack-plugin');

plugins: [
  new HtmlwebpackPlugin({
    template: 'src/index.html'
  })
];
```

The two changes we made were to import the newly installed plugin at the top of the file and then add a plugins section at the end of the configuration object, where we passed in a new instance of our plugin.

## Code Splitting

Web applications tend to grow big as features are developed. The longer it takes for your application to load, the more frustrating it's to the user. This problem is amplified in a mobile environment where the connections can be slow. Even though splitting bundles can help a notch, they are not the only solution, and you can still end up having to download a lot of data. Fortunately, it's possible to do better thanks to code splitting. It allows loading code lazily as you need it.

To demonstrate the idea of code splitting, you can use dynamic import. Given Babel doesn't support the dynamic import syntax out of the box, it needs babel-plugin-syntax-dynamic-import to work.

Install it first:

```shell
npm install babel-plugin-syntax-dynamic-import --save-dev
```

To connect it with the project, adjust the configuration as follows:

```
// .babelrc

{

  "plugins": ["syntax-dynamic-import"],

  ...
}
```

If one section of your app has heavy dependencies that the rest of the app doesn’t need, it’s a good case for splitting into its own bundle. We can demonstrate this by adding a new module named dashboard.js that requires d3.

```shell
npm install d3 --save
```

```javascript
// src/dashboard.js
import * as d3 from 'd3';

console.log('Loaded!', d3);

export const draw = () => {
  console.log('Draw!');
};
```

Import dashboard.js from the bottom of app.js:

```javascript
// ...

const routes = {
  dashboard: () => {
    System.import('./dashboard')
      .then(dashboard => {
        dashboard.draw();
      })
      .catch(err => {
        console.log('Chunk loading failed');
      });
  }
};

// demo async loading with a timeout
setTimeout(routes.dashboard, 1000);
```

If you run npm run build, you’ll see a mysterious new bundle `0.bundle.js`. This file is your split point. Examining the file reveals that webpack has wrapped the code in a webpackJsonp block and processed the code bit. This 0.bundle.js will be fetched on demand with a JSONP request, loading the file from file system is going to do anything.

## Webpack Dev Server

Live reloading can really improve the developer experience by refreshing automatically whenever files are changed. Simply install it and start it with webpack-dev-server and you’re off to the races.

```shell
npm install webpack-dev-server@latest --save-dev
```

Modify the start script in `package.json`:

```json
"start": "webpack-dev-server --inline"
```

Run npm start to start the server and open http://localhost:8080 in your browser. Try it out by changing any of the src files, example change a thing or two in app.js or a add a new style property in `style.scss`. This time the changes will not only be watched by webpack but they will be reflected on the client side too.

### Hot Module Replacement

Hot Module Replacement (HMR) builds on top of the Webpack Dev Server. It enables an interface that makes it possible to swap modules live. For example, style-loader can update your CSS without forcing a refresh. As CSS is stateless by design, implementing HMR for it's ideal.

If you are working with Single Page Applications, during development you’ll be making a lot of small changes to components and you want to see these reflected in a real browser where you see the output and interact with it. By refreshing the page manually or with live reload your global state is blown away and you need to start from scratch. Hot module replacement comes to the rescue in this case.

Make one final edit to the start script in `package.json`:

```json
"start": "webpack-dev-server --inline --hot"
```

However, there is another way to implement HMR in our web application. We can skip the `--hot` flag entirely and add some configuration to our `webpack.config.js`:

```javascript
{
  devServer: {
    // Don't refresh if hot loading fails. Good while
    // implementing the client interface.
    hotOnly: true,

    // If you want to refresh on errors too, set
    // hot: true,
  },
  plugins: [
    // Enable the plugin to let webpack communicate changes
    // to WDS. --hot sets this automatically!
    new webpack.HotModuleReplacementPlugin(),
  ],
}
```

Either way that suits you. HMR is a great asset when building web applications. It is also one of those aspects of webpack that makes it attractive for developers and webpack has taken its implementation far.
