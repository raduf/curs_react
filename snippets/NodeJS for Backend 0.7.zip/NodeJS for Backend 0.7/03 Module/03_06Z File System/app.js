
const fs = require('fs');

// sync version ar trebui evitate (blocheaza thread-ul)
const files = fs.readdirSync('./dir');
console.log('Lista de fisiere sync: ', files);

let dir = './dir';
// let dir = './ddir';  // nu exista - vom afisa obiectul Error in consola

fs.readdir(dir, function(err, files) {
    if (err) 
        console.log('Erori la citire folder', err)
    else {
        console.log('Lista de fisiere async (non-blocking): ', files)
    }

});
