
# 03_09x Http


## Cream un server

- obiectul returnat de `http.createServer` este un EventEmitter

```js
// app.js


const http = require('http');

const server = http.createServer();

server.on('connection', (socket) => {
    console.log('Conexiune noua...');
});

server.listen(3030);
console.log('Serverul asculta pe portul 3030...');


```

- acum ne putem conecta din Browser si vom primi mesajul `Conexiune noua...`

- in practica nu ascultam evenimentul `connection`
    - vom lucra la un nivel mai inalt


---

## Trimitem o functie callback metodei createServer()

```js
// app.js

const server = http.createServer((req, res) => {
    if (req.url === '/') {
        res.write('Root route response');
        res.end();
    }
    if (req.url === '/api/projects') {
        res.write(JSON.stringify([
            { id: 1, name: 'Project One'},
            { id: 2, name: 'Project Two'},
            { id: 3, name: 'Project Three'},
        ]));
        res.end();
    }
});


```
