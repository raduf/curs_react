
var project = 'Project One'

console.log(project);

