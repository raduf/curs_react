
const http = require('http');

//---------------
// 1 - asscultare eveniment connection
// const server = http.createServer();

// server.on('connection', (socket) => {
//     console.log('Conexiune noua...');
// });
//---------------


//2 acum vom trimite o functie callback metodei createServer()
const server = http.createServer((req, res) => {
    if (req.url === '/') {
        res.write('Root route response');
        res.end();
    }
    if (req.url === '/api/projects') {
        res.write(JSON.stringify([
            { id: 1, name: 'Project One'},
            { id: 2, name: 'Project Two'},
            { id: 3, name: 'Project Three'},
        ]));
        res.end();
    }
});


server.listen(3030);
console.log('Serverul asculta pe portul 3030...');
