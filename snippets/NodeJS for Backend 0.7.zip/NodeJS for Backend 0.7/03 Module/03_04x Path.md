
# 03_04x Path


---

## Importam modulul `path` si folosim metoda `parse()`

```js
// app.js

const path = require('path')

var parsedPath = path.parse(__filename);

console.log(parsedPath.base); // numele fisierului
console.log(parsedPath.ext); // extensia 
console.log(parsedPath.name); // numele fisierului
console.log(parsedPath.dir); // calea unde se afla modulul

console.log(parsedPath);

```
