
# 03_01x Obiectul global

- obiectul global in Node versus Browser

- vom scrie un cod simplu pentru Browser si il vom rescrie pentru Node
    - vom utiliza obiectul global
    - vom observa comportamentul in Node versus Browser

---

## Aplicatia pentru Browser

```js
//+ global-browser.js

var project = 'Project One'

console.log(project);
global.console.log(project);

console.log(global.project);

```

- rulam codul in consola de Browser (sau jsbin.com)

- obiectul `console` este global, il putem accesa de oriunde


---

## Aplicatia pentru Node

- putem verifica obiectul `global` in Node:

```shell
> node
Node> global

# Obiectul global
{ console: [Getter],
  ...
  process: ...
  ...
  clearImmediate: [Function],
  clearInterval: [Function],
  clearTimeout: [Function],
  setImmediate: { [Function: setImmediate] [Symbol(util.promisify.custom)]: [Function] },
  setInterval: [Function],
  setTimeout: { [Function: setTimeout] [Symbol(util.promisify.custom)]: [Function] },
  module:
   Module {
     id: '<repl>',
     exports: {},
     parent: undefined,
     filename: null,
     loaded: false,
     children: [],
     paths: [ ... ]
...
require:
   { [Function: require]


```

```js
//+ global-node.js

var project = 'Project One'

console.log(project);
global.console.log(project);

console.log(global.project);

```

> rulam aplicatia `> node global-node.js`

- Observam ca in Node, variabilele declarate nu ajung pe obiectul global

- Sunt disponibile doar in acest fisier

- Fisierul este un modul cu `scope` privat



---
