###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# 03_00_01 Module BuiltIn

> Cele mai utile module din NodeJS

- File System (pentru lucrul cu fisierele si directoarele)

- Http (vom folosi Http ca sa cream servere web)

- OS (pentru lucrul cu sistemul de operare)

- Path

- Process

- Query Strings

- Stream (pentru lucrul cu datele transmise ca stream )

---

## Path

`path.parse(path)`

[Ex: 03_04x]

---

## OS

- pentru a afla memoria totala
    - `os.totalmem()`

- pentru a afla memoria disponibila
    - `os.freemem()`

- pentru a afla de cand nu a mai fost repornit serverul
    - `os.uptime()`

