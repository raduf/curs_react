
const os = require('os');

let totalMem = os.totalmem();
let freeMem = os.freemem();

let uptime = os.uptime() / 1024 / 1024 ;
let platform = os.platform() / 1024 / 1024 ;
let cpus = os.cpus();
let version = os.version;

let user = os.userInfo();
let homedir = os.homedir();

console.log(`totalMem: ${totalMem}`)
console.log(`freeMem: ${freeMem}`)

console.log(`uptime: ${uptime}`)

console.log(`platform: ${platform}`)
console.log(`cpus: ${cpus}`)
console.log(`version: ${version}`)

console.log(`user: ${user}`)
console.log(`homedir: ${homedir}`)
