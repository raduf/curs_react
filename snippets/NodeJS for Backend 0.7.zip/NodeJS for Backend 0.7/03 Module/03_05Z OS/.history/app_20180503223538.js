
const os = require('os');

let totalMem = os.totalmem() / 1024 / 1024 / 1024;
let freeMem = os.freemem() / 1024 / 1024 / 1024;

let uptime = os.uptime();
let platform = os.platform();
let cpus = os.cpus();
let version = os.version;

let user = os.userInfo();
let homedir = os.homedir();

console.log(`totalMem: ${totalMem.toFixed(2)} GB`)
console.log(`freeMem: ${freeMem.toFixed(2)} GB`)

console.log(`uptime: ${uptime}`)

console.log(`platform: ${platform}`)
console.log(`cpus: ${cpus}`)
console.log(`version: ${version}`)

console.log(`user: ${user}`)
console.log(`homedir: ${homedir}`)
