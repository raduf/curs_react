
# 03_05x File System

- vom utiliza modulul de manipulare a fisierelor `fs`

---

## Folosim `fs` pentru a citi lista de fisiere din `./dir`

- ulterior generm o eroare (folder inexistent)

```js
// app.js

const fs = require('fs');

// sync version ar trebui evitate (blocheaza thread-ul)
const files = fs.readdirSync('./dir');
console.log('Lista de fisiere sync: ', files);

let dir = './dir';
// let dir = './ddir';  // nu exista - vom afisa obiectul Error in consola

fs.readdir(dir, function(err, files) {
    if (err) 
        console.log('Erori la citire folder', err)
    else {
        console.log('Lista de fisiere async (non-blocking): ', files)
    }

});

```

