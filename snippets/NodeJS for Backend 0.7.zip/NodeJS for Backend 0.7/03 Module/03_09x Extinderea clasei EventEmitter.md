
# 03_07x Extinderea clasei EventEmitter

- vom extinde clasa EventEmitter pentru clasa Task

---

## Rescriem modulul task.js sa exporte o clasa noua Task

- stergem obiectul `evEmitter`
- stergem exportul `emitter`
- cream clasa `Task exports EventEmitter`
- exportam clasa `Task`

- folosim `this.emit` in loc de `evEmitter.emit`

```js
// task.js


const EventEmitter = require('events')

class Task extends EventEmitter {
    saveTask() {
        console.log('task module::Salvez task-ul 102...');
        this.emit('taskSaved', { id: 102, subject: 'Create new design', closed: false });
    }
}

module.exports = Task;

```


---

## Importam clasa, cream o instanta noua si utilizam functia `saveTask`

```js
// app.js

const Task = require('./task')

...
let task = new Task();

task.on('taskSaved', (ev) => {
    console.log('Task-ul a fost salvat: ', ev);
});


task.saveTask();

```