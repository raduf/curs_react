
# 03_06x Evenimente 


# 


---

## Cream un obiect de tip EventEmitter si generam si ascultam evenimente custom

```js
// app.js

//1 clasa EventEmitter - vom avea nevoie de instanta (obiect de acest tip)
const EventEmitter = require('events')
const evEmitter = new EventEmitter();

//3 ascultam evenimente de tipul `projectSaved` 

//3a evEmitter.addListener('projectSaved', function(){
//     console.log('Proiectul a fost salvat');
// });

//3b on este alias pentru addListener 
evEmitter.on('projectSaved', function(){
    console.log('Proiectul a fost salvat');
});


//2 genereaza un eveniment
evEmitter.emit('projectSaved')

//4 
setTimeout( function(){
    evEmitter.emit('projectSaved')
}, 1500)

```

- 