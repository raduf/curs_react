
//1 clasa EventEmitter - vom avea nevoie de instanta (obiect de acest tip)
const EventEmitter = require('events')
const evEmitter = new EventEmitter();

//3 ascultam evenimente de tipul `projectSaved` 

//3a evEmitter.addListener('projectSaved', function(){
//     console.log('Proiectul a fost salvat');
// });

//3b on este alias pentru addListener 
evEmitter.on('projectSaved', function(){
    console.log('Proiectul a fost salvat');
});


//2 genereaza un eveniment
evEmitter.emit('projectSaved')

//4 
setTimeout( function(){
    evEmitter.emit('projectSaved')
}, 1500)


//-----------------
//5 Event Arguments

evEmitter.on('taskDeleted', function(taskid, success){
    console.log('Operatie de stergere task: ', taskid, success);
});

evEmitter.emit('taskDeleted', 101, true);

//6 Folosim obiecte in loc de argumente (ES6)
evEmitter.on('taskSaved', (ev) => {
    console.log('Task-ul a fost salvat: ', ev);
});

setTimeout( () => {
    evEmitter.emit('taskSaved', { id: 102, subject: 'Create new design', closed: false });
}, 2000)

