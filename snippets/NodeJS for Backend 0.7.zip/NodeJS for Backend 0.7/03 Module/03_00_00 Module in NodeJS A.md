###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Module in NodeJS


---

## Obiectul global

- in Browser: `window`

- in NodeJS: `global`

[Ex: 03_01]


---

## Module in Node

- In Node, fiecare fisier este un modul
    - are `scope` privat
    - variabilele cu acelasi nume din fisiere diferite nu se suprascriu (ca in Browser)

- Orice aplicatie Node are cel putin un modul
    - `main module`

- Fiecare fisier are access la un obiect privat special `module`

```js
// app.js

console.log(module)

 ```

 ```js
 Module {
  id: '.',
  exports: {},
  parent: null,
  filename: 'F:\\...\\03 Module\\03_01Z Obiectul global\\global-node.js',
  loaded: false,
  children: [],
  paths:
   [ 'F:\\...\\03 Module\\03_01Z Obiectul global\\node_modules',
     'F:\\...\\03 Module\\node_modules',
     'F:\\...\\node_modules',
     'F:\\WORK_Courses\\#NodeJS for Backend\\node_modules',
     'F:\\WORK_Courses\\node_modules',
     'F:\\node_modules' ] }
 ```

 - path reprezinta un array de locatii in care se cauta modulele importate
    - in ordinea specificata


[Ex: 03_02]


---

## Functia `wrapper` care creeaza modulul

- fortand o eroare pe prima linie in app.js descoperim signatura functiei `wrapper`

```js
// app.js
const a = 100; a = 200;
...
```

- raspunsul in consola este:

```js
(function (exports, require, module, __filename, __dirname) { const a = 100; a = 200;

TypeError: Assignment to constant variable.
...

```

- Aceasta functie wrapper incorporeaza codul din fisiere (app.js) 

- Node executa codul din `app.js` dupa ce il pune in interiorul unei functii cu signatura:

` function (exports, require, module, __filename, __dirname) { ... } `

- Asta este motivul pentru care in interiorul fisierelor avem acces la acele variabile:

    - `exports, require, module, __filename, __dirname`


[Ex: 03_03x]
