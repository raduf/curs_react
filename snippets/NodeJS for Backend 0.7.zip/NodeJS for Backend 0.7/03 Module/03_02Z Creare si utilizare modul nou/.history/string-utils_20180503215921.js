
const a = 100; a = 200;
function compareInsensitive(s1, s2) {
    return s1.toLowerCase() === s2.toLowerCase()
}

function compareSensitive(s1,s2) {
    return s1 === s2
}

module.exports.compareCI = compareInsensitive
module.exports.compareCS = compareSensitive

