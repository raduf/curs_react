
function compareInsensitive(s1, s2) {
    return s1.toLowerCase() === s2.toLowerCase()
}

module.exports.compareCI = compareInsensitive
