
const sutils = require('./string-utils')

console.log(sutils);

console.log( sutils.compareCI('NodeJS', 'NodeJs') );
console.log( sutils.compareCS('NodeJS', 'NodeJs') );

