
# 03_07x Ascultarea evenimentelor emise in alt modul

- in prima etapa vom genera un eveniment din alt modul
    - si vom asculta acel eveniment din `app.js` 

- in a doua etapa vom extinde clasa EventEmitter pentru clasa Task

---

## Copiem liniile care creeaza o noua instanta EventEmitter in modul nou


```js
//+ task.js

const EventEmitter = require('events')
const evEmitter = new EventEmitter();

```

---

## Cream o noua functie care afiseaza un mesaj si emite un Eveniment `taskSaved`


```js
// task.js

...
const saveTask = () => {
    console.log('task module::Salvez task-ul 102...');
    evEmitter.emit('taskSaved', { id: 102, subject: 'Create new design', closed: false });
}

module.exports.saveTask = saveTask;

```

> in app.js modificam codul astfel:

```js
// app.js

const task = require('./task')

...
// listener-ul ramane neschimbat
evEmitter.on('taskSaved', (ev) => {
    console.log('Task-ul a fost salvat: ', ev);
});

// salvarea unui task genereaza si evenimentul
// dar nu functioneaza pentru ca sunt doua instante diferite de EventEmitter
task.saveTask();

```


---

## O solutie la problema de sus este sa ascultam pe aceeasi instanta de pe care se emite

```js
// task.js

...
module.exports.emitter = evEmitter;
```

```js
// app.js

...
//2 daca ascultam evenimentele pe aceeasi instanta este ok
task.emitter.on('taskSaved', (ev) => {
    console.log('TaskEmitter::Task-ul a fost salvat: ', ev);
});

task.saveTask();

```

- trebuie sa ne abonam inainte de emitere (saveTask())

