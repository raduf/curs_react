# 03_03x Obiecte disponibile in interiorul modulului

- vom verifica obiectele primite ca parametri in modul
    - prin intermediul functiei `module wrapper`

---

## Afisam informatii in consola pentru obiectele primite ca argumente

```js
// app.js

console.log('exports: ', exports);
console.log('require: ', require);
console.log('module: ', module);
console.log('__filename: ', __filename);
console.log('__dirname: ', __dirname);

```
