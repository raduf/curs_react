// >node global-node.js

//01 obiectul global
var project = 'Project One'

console.log(project);
global.console.log(project);

console.log(global.project);

//02 afisam obiectul `module`
console.log(module);
