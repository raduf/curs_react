// > node global-node.js

var project = 'Project One'

console.log(project);
global.console.log(project);

console.log(global.project);
