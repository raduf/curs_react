
# 03_02x Creare si utilizare modul nou

- vom adauga un nou modul

- vom importa modulul in app.js

- vom utiliza o functie pusa la dispozitie de modul

---

## Adauga modul string-utils.js


```js
//+ string-utils.js

function compareInsensitive(s1, s2) {
    return s1.toLowerCase() === s2.toLowerCase()
}

function compareSensitive(s1,s2) {
    return s1 === s2
}

module.exports.compareCI = compareInsensitive
module.exports.compareCS = compareSensitive

```

- Orice variabila sau functie adaugam obiectului `module.exports` 
    - va deveni disponibila pentru alte module



---

## Importam modulul in app.js

- importam modulul si afisam obiectul exportat

- apoi vom utiliza una din functiile exportate

```js
// app.js

const sutils = require('./string-utils')

console.log(sutils);

```

```> node app.js```

```js
// raspuns consola:

{ compareCI: [Function: compareInsensitive],
  compareCS: [Function: compareSensitive] } 
```


---

## Utilizam una din functiile exportate

```js
// app.js

...
console.log( sutils.compareCI('NodeJS', 'NodeJs') );
console.log( sutils.compareCS('NodeJS', 'NodeJs') );

```


---

> daca am avea o singura functie ce este exportata putem sa scriem

```js
// string-utils.js

...
module.exports = compareInsensitive
```

- iar in app.js folosim direct functia:

```js
// app.js

const scompare = require('./string-utils')
console.log( scompare('NodeJS', 'NodeJs') );

```