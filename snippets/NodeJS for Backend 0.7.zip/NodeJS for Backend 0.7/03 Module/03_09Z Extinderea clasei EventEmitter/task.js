
const EventEmitter = require('events')

class Task extends EventEmitter {
    saveTask() {
        console.log('task module::Salvez task-ul 102...');
        this.emit('taskSaved', { id: 102, subject: 'Create new design', closed: false });
    }
}

module.exports = Task;
