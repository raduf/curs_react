
const Task = require('./task')

const EventEmitter = require('events')
const evEmitter = new EventEmitter();

evEmitter.on('taskDeleted', function(taskid, success){
    console.log('Operatie de stergere task: ', taskid, success);
});

evEmitter.emit('taskDeleted', 101, true);


let task = new Task();

task.on('taskSaved', (ev) => {
    console.log('Task-ul a fost salvat: ', ev);
});


task.saveTask();

