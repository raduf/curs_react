
---

## Modulul de fisiere `fs`

- Async versus Sync

- Mai toate functiile de manipulare fisiere au doua variante
    - sync si async
    - cele cu access sincronic au sufixul Sync

[Ex: 03_05x]

---

## Evenimente

- Unul dintre cele mai importante concepte in Node (si JavaScript) este Evenimentul

- Un eveniment este o notificare a unei actiuni ce a avut loc in aplicatie
    - poate fi generata de un user dar nu este obligatoriu
    - de exemplu un click de mouse in DOM genereaza un request catre server
    - la randul lui modulul de http genereaza un eveniment cand un request are loc
    - alte evenimente pot aparea la intervale de timp stabilite (intr-un setInterval(), de exemplu)

- O multime de clase din Node genereaza evenimente
    - avem posibilitatea sa raspundem la aceste evenimente

---

## EventEmiter

- una dintre cele mai importante clase ale modulului Event este EventEmitter

- multe clase extind aceasta clasa pentru a beneficia de mecanismul de generare evenimente

- daca clasele noastre au nevoie sa comunice prin evenimente (sa lanseze evenimente)
    - putem sa extindem clasa EventEmitter si vom beneficia deja de acest mecanism

[Ex: 03_06x]
[Ex: 03_07x]
[Ex: 03_08x]


---

## HTTP

- Avem cateva clase importante in modulul Http
    - http.Agent
    - http.ClientRequest
    - http.Server
    - http.ServerResponse

[Ex: 03_09x]
