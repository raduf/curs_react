// fortam eroare pentru a observa in consola signatura functiei wrapper
// const a = 100; a = 200; 

console.log('exports: ', exports);
console.log('require: ', require);
console.log('module: ', module);
console.log('__filename: ', __filename);
console.log('__dirname: ', __dirname);

