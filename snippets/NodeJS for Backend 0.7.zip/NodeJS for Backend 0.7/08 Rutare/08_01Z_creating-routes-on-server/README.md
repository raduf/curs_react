# Creating Routes

* install express and body-parser
* use data from `./db/db.json`
* define port and app constant
* add app.listen() to prompt that server starts running
* use middleware bodyParser.json() to parse JSON data
* define two routes using GET REQUEST
  * `/api/projects`
  * `/api/tasks`
