###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Server Routing versus client Routing in Web Applications

- Most web applications use the concept of routing. 

- There are different ways to handle routing both on server and client

 - Routing is the concept in which requests are handled by some snippets of code
 
 - It is used for navigating in a web application by clicking on a link 
    - which further, changes the URL to provide access to a different endpoint in the application.

---

## Server Side Routing

- whenever the endpoint changes, some form of data is requested by the application. 

- Ex: The server will query the database to fulfill the request and sends it as a response. 

- In most Expressjs applications we define our routes in a separate file called `routes.js` 


```javascript
/* GET todo listing. */
router.get('/', function(req, res, next) {
  db.todo
    .findAll({})
    .then(todos =>
      res.json({
        error: false,
        data: todos
      })
    )
    .catch(error =>
      res.json({
        error: true,
        data: [],
        error: error
      })
    );
});
```

- Server side routes cause the web application to refresh the page.

- This means, whenever a GET request is sent to the server, the response always comes back to the client as a new document. 

- This is resources consuming task. For every request, if there is a full page refresh, some of the same data will be transferred back and forth such as the header of the application. 

- Refreshing a page takes time and consumes network resources.

- This is the reason which is why client side routing exists.

---


## Client Side Routing

- Most modern day web applications also behave like single page application 

- data once fetched from the server is rendered by the client without refreshing the whole page, 

- only refresh that section of the web page that changes with the ongoing request.

- A client-side route is handled internally by the client app

- Client side routing makes web applications behave faster since less amount of data is being processed and transferred. 

---

### ReactJS Routing

- modern front-end JavaScript framework such as ReactJS have its own library to implement client side routing (React Router)

- React router provides an API for Reactjs applications for dynamic client-side routing. 

- It allows developers to build web apps with navigation but without refreshing the whole web page. 


```javascript
import React, { Component } from 'react';
import '../styles/App.css';
// import route Components here
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
          </Switch>
        </div>
      </Router>
    );
  }
}
export default App;
```

---

- For each existing route, we define a path and the component associated with it. 

- This `path` will be reflected in the browser's address bar.

- If no data is needed by the component, the browser doesn't send server requests

- It dynamically simulate changing routes by removing and adding nodes in DOM, only on the Browser side

---

