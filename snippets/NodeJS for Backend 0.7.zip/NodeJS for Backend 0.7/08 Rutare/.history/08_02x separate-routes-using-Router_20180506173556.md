
# 08_02x separate-routes-using-Router

- vom separa rutele si vom folosi `express.Router()`

--- 

