
# 

- folosim `body-parser` si `express` pentru a crea un server si rutele asociate lui

- use data from `./db/db.json`

---

## Instalam `body-parser` si `express`

```shell

npm install body-parser@1.18.2
npm install express@4.16.2

```

---

## Cream serverul si rutele

* define port and app constant
* add app.listen() to prompt that server starts running
* use middleware bodyParser.json() to parse JSON data
* define two routes using GET REQUEST
  * `/api/projects`
  * `/api/tasks`

```js
// server.js

const express = require('express');
const bodyParser = require('body-parser');

const data = require('./db/db.json');

const app = express();
const port = process.env.PORT || 3001;

app.use(bodyParser.json({ type: 'application/json' }));

// Get a list of all projects
app.get('/api/projects', (req, res) => {
	res.json(data.projects);
});

// Get a list of all tasks
app.get('/api/tasks', (req, res) => {
	res.json(data.tasks);
});

app.listen(port, () => {
	console.log(`Server running at http://localhost:${port}`);
});


```

