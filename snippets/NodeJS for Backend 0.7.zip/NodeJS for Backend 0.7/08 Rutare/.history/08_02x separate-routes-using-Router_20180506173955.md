
# 08_02x separate-routes-using-Router

- vom separa rutele si vom folosi `express.Router()`

--- 

## create a folder `api` in root

---

## inside `api/` folder create file called `routes.js`


---

## use `express.Router()` class to define routes

 - use module.exports to make class variable available for use in `server.js`

