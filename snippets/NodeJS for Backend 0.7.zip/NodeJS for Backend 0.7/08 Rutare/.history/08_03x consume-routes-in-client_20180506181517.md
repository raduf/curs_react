
# 08_03x consume-routes-in-client

---

## 


## Client: install and use `axios`

`npm install axios@0.18.0`

```js
// client/src/components/ProjectList.js

...
import axios from 'axios';

const API = 'http://localhost:3001/api/projects';

export default class ProjectList extends Component {
	state = {
		projects: []
	};

	componentDidMount() {
		axios.get(`${API}`).then(res => {
			const projects = res.data;
			this.setState({ projects });
			console.log(projects);
		});
    }
...

```



```js
// client/src/components/TasksList.js

import axios from 'axios';

const API = 'http://localhost:3001/api/tasks';

export default class TasksList extends Component {
	state = {
		tasks: []
	};

	componentDidMount() {
		axios.get(`${API}`).then(res => {
			const tasks = res.data;
			this.setState({ tasks });
			console.log(tasks);
		});
	}

	...
}

```

- pornim cele doua servere si afisam rutele pe client: `/projects`, `/tasks`
    - server: `node server.js`
    - client: `npm start` sau `yarn start`

- clientul ruleaza la adresa: `http://localhost:3000`

- rutele sunt definite in `App.js`

```js
    <div className="App">
        <Switch>
            <Route path="/" exact component={ProjectList} />
            <Route path="/tasks" exact component={TasksList} />
            <Redirect from="/projects" to="/" />
        </Switch>
    </div>
```

