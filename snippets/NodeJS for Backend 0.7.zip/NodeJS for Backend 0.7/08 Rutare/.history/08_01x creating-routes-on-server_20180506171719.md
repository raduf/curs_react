
# 

- folosim `body-parser` si `express` pentru a crea un server si rutele asociate lui

---

## Instalam `body-parser` si `express`

```shell

npm install body-parser@1.18.2
npm install express@4.16.2

```