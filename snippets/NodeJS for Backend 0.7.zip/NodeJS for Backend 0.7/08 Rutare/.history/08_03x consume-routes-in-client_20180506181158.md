
# 08_03x consume-routes-in-client

---

## Client: install and use `axios`

`npm install axios@0.18.0`

```js
// client/src/components/ProjectList.js

...
import axios from 'axios';

const API = 'http://localhost:3001/api/projects';

export default class ProjectList extends Component {
	state = {
		projects: []
	};

	componentDidMount() {
		axios.get(`${API}`).then(res => {
			const projects = res.data;
			this.setState({ projects });
			console.log(projects);
		});
    }
...

```



```js
// client/src/components/TasksList.js



```