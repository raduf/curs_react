
# 08_03x consume-routes-in-client

---

## 