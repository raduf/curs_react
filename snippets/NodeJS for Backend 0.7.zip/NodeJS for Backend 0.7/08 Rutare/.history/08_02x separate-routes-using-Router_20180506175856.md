
# 08_02x separate-routes-using-Router

- vom separa rutele si vom folosi `express.Router()`

--- 

## create a folder `api` in root

---

## inside `api/` folder create file called `routes.js`


---

## use `express.Router()` class end re-export it

 - use module.exports to make class variable available for use in `server.js`

```js
// api/routes.js

const routes = require('express').Router();
const data = require('../db/db.json');

module.exports = routes;

```

---

## move both routes from `server.js` to `routes.js`

- also add `res.status()` as chain method while sending JSON data

```js
// api/routes.js

...
// Get a list of all projects
routes.get('/projects', (req, res) => {
  res.status(200).json(data.projects);
});

// Get a list of all tasks
routes.get('/tasks', (req, res) => {
  res.status(200).json(data.tasks);
});

module.exports = routes;


```

---

## import `routes` from `./api/routes`

- consume our newly created routes after we define middleware functions

~~`const data = require('./db/db.json');`~~

```js
// server.js

const routes = require('./api/routes');

...
app.use(bodyParser.json({
	type: 'application/json'
}));

// consume API
app.use('/api', routes);
...

```


