# Consume Routes in Client

* in client install axios
* fetch data from our api running on separate port using axios
* in server install cors
* use `cors` as middleware in `server.js`
