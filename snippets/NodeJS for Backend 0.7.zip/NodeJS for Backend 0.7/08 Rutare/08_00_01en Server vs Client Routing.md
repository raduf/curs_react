###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Server Routing versus client Routing in Web Applications

Most web applications use the concept of routing. There are different ways to handle routing both on server and client part of the application. Routing is the concept in which HTTP requests or client requests are handled by some snippets of code. It is used for navigating in a web application by clicking on a link which further, changes the URL to provide access to a different endpoint in the application.

## Server Side Routing

In server side routing, whenever the endpoint changes, some form of data is requested by the application. This is the main purpose of server side routing. The server will query the database to fulfill the request and sends it as a response. In most Expressjs applications we define our routes in a separate file called `routes.js` which handles the business logic such as database queries. For example, take a look at the GET request that will handle the by fetching the list of items from the database.

```javascript
/* GET todo listing. */
router.get('/', function(req, res, next) {
  db.todo
    .findAll({})
    .then(todos =>
      res.json({
        error: false,
        data: todos
      })
    )
    .catch(error =>
      res.json({
        error: true,
        data: [],
        error: error
      })
    );
});
```

Server side routes cause the web application to refresh the page. This means, whenever a GET request is sent to the server, the response always comes back to the client as a new document. This is resources consuming task. For every request, if there is a full page refresh, some of the same data will be transferred back and forth such as the header of the application. Refreshing a page takes time and consumes network resources.

## Client Side Routing

This is the reason which is why client side routing exists. Most modern day web applications also behave like single page application where common data once fetched from the server is rendered by the client or instead of refreshing the whole page, only refresh that section of the web page that changes with the ongoing request.

A client-side route is handled internally by the browser. Client side routing makes web applications behave faster since less amount of data is being processed. For example, modern front-end JavaScript framework such as Reactjs have its own library to implement client side routing. This library is known as React Router.

React router provides an API for Reactjs applications for dynamic client-side routing. In other words, it allows developers to build web apps with navigation but without refreshing the whole web page. Since Reactjs is component based web framework, React Router also uses components to re-render and showcase the information through that component. To use react router, we need to install it using `npm` in our Reactjs application.

```shell
npm install --save react-router-dom
```

Since the latest version, `react-router` library has been broken down into different packages. We need one of them. To start implementing the client side routing, we use `<BrowserRouter>`. In a typical Reactjs application, if we are not using routing, the `App` component is our parent or root level component. But when we start using routing, `BrowserRouter` is going to be the wrapper where every other component we create in our application will live inside.

```javascript
import React, { Component } from 'react';
import '../styles/App.css';
// import route Components here
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
          </Switch>
        </div>
      </Router>
    );
  }
}
export default App;
```

The above snippet of code is a simple implementation of react router library. Suppose we have two web components in our application `Home` and `About`. Both contain some information for which we do not want to request to the server for the reasons we discussed above and render them only on the client. To navigate from one page to another and back, we make use of different components from react router library.

We use `Switch` component to form a group of all the routes in our application. `Switch` helps us to iterate over the children elements which are defined as props to `Route` component. For each existing route, we define a path and the component associated with it. This `path` will be reflected in the browser's address bar.
