
# 05_01x simple-nodejs-web-server

- vom crea un server web 

* folosim modulele `http` si `fs`
* vom utiliza `fs` pentru a citi fisierul index
* `__dirname`: variabila care contine directorul modulului curent

---

## Cream serverul web

```js
// server.js

const http = require('http');
const fs = require('fs');

const hostname = 'localhost';
const port = 3000;

const server = http.createServer((req, res) => {
	let filePath = '.' + req.url;

	if (filePath == './') {
		filePath = __dirname + '/public/index.html';
	}

	fs.readFile(filePath, (err, data) => {
		if (err) {
			res.statusCode = 500;
			res.setHeader('Content-Type', 'text/plain');
			res.end('Error Getting File.');
		} else {
			res.statusCode = 200;
			res.setHeader('Content-Type', 'text/html');
			res.end(data);
		}
	});
});

server.listen(port, hostname, () => {
	console.log(`Server running at http://${hostname}:${port}/`);
});

```

- pornim serverul cu `node server.js`

* am folosit `fs.readFile` pentru a citi `index.html` din `public/`
* am adaugat clauza if pentru a trata eventualele erori la citire `public/index.html`
* cu `server.listen()` pornim serverul
* pentru a afisa un mesaj cu adresa si portul serverului 
    - trimitem o functie ca al treilea parametru pentru `listen`
    - functia este executata dupa ce porneste serverul



