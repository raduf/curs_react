
# 01_02Z Aplicatie interactiva

- vom crea o aplicatie NodeJS initializata cu `npm init` sau `yarn init`

- vom instala si utiliza un modul `readline-sync`

- aplicatia va cere in consola o lista de numere si face suma lor

---

## Initializare proiect nou

- daca in calea avem `#` npm init nu functioneaza corect

- numele aplicatiei nu trebuie sa aibe spatii

```shell
> npm init
# sau
> yarn init
```


---

## Instalare readline-sync

```shell

> npm install --save readline-sync
# sau 
> yarn add readline-sync

```

---

## Scriem aplicatia 

```js
//+ app.js

const readlineSync = require('readline-sync')

let numbers = readlineSync.question('Oricate numere despartite cu `,`: ');

let arr = numbers.split(',');
const reducer = (acc, current) => parseInt(acc) + parseInt(current)

function sum(numbersArr){
    return numbersArr.reduce( reducer, 0 )
}

console.log('Suma este: ', sum(arr) );

```

> Executam aplicatia si raspunsul nostru trebuie sa un string similar cu 


```shell
 > node app.js 
 # furnizam lista de numere: "1,2,3"
 > Oricate numere despartite cu `,`: 1,2,3
 > Suma este: 6
 ```

 ---
 