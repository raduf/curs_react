
# Server versus Client

- NodeJS este o tehnologie server
    - permite executarea codului JS pe server

---

- Serverul ofera servicii

- Clientul cere servicii

---

- Clientul cere un serviciu (Request)

- Serverul calculeaza si raspunde (Response)

- Cele doua parti comunica folosind mesaje standard

- In aplicatiile web, avem 
    - WebServer
    - Browser (clientul)
    - HTTP standardul de comunicare (protocol)

---

## Ce caracteristici ar trebui sa aibe aplicatia Server

- Cod Modular

- Sa poata lucra cu fisiere

- Sa poata accesa baze de date

- Sa comunice peste internet

- Sa poata prelua request-uri si sa trimita raspunsul

- Sa nu se blocheze cu task-uri care dureaza mult
    
> JavaScript nu furnizeaza toate capabilitatile de mai sus. NodeJS completeaza caracteristicile necesare furnizand module speciale.


 ---

