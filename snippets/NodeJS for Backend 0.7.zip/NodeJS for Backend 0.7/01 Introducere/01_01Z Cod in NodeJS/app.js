
function sum(a, b) {
    return a + b;
}

var rez = sum(10, 20);

console.log(rez);
