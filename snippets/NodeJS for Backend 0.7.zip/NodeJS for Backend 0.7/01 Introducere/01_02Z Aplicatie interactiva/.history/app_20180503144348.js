const readlineSync = require('readline-sync')

let numbers = readlineSync.question('Oricate numere despartite cu `,`: ');

let arr = numbers.split(',');
const reducer = (acc, current) => parseInt(acc) + parseInt(current)

function sum(numbersArr){
    return numbersArr.reduce( reducer, 0 )
}

console.log('Suma este: ', sum(arr) );
