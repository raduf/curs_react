const readlineSync = require('readline-sync')

let numbers = readlineSync.question('Oricate numere despartite cu `,`: ');

let arr = numbers.split(',');

function sum(numbersArr){
    return numbersArr.reduce( (acc, item) => acc + +item )
}

console.log('Suma este: ', sum(arr) );
