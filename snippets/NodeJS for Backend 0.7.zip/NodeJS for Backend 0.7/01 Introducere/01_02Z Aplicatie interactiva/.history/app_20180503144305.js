const readlineSync = require('readline-sync')

let numbers = readlineSync.question('Oricate numere despartite cu `,`: ');

let arr = numbers.split(',');

function sum(numbersArr){
    return numbersArr.reduce( (acc, current) => parseInt(acc) + parseInt(current), 0 )
}

console.log('Suma este: ', sum(arr) );
