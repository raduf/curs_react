
# 01_01Z Cod in NodeJS

- vom crea o aplciatie minimala in NodeJS

---

```js
//+ app.js


function sum(a, b) {
    return a + b;
}

var rez = sum(10, 20);

console.log(rez);


```

- Executam codul cu `>node app.js`

- Am rulat cod JavaScript in afara Browserului

