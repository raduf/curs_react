
# Introducere

---

## Ce este NodeJS

- Un mediu de executie pentru JavaScript in afara Browserului

- NodeJS ne permite rularea de cod JavaScript si pe backend, nu doar in Browsere

- Practic, putem avea servere de aplicatie scrise in JavaScript

- Cel mai adesea, vom folosi NodeJS pentru a dezvolta API-uri
    - Application Programming Interface

---    

## NPM

- Exista pentru NodeJS un repository de librarii open source
    - npmjs.com 

- npm este un package manager pentru Node
    - exista si alternative precum yarn
    - acestea se conecteaza la acelasi repository (npmjs)

- Pentru fiecare cerinta a aplicatiei noastre, exista probabil o librarie open source

- Licentierea MIT a permis dezvoltarea rapida a ecosistemului Node


---

## JavaScript engines

- Browserul foloseste un Engine JS pentru a traduce codul JS in Machine Code (inteles de calculatoare)

- Exista mai multe motoare pentru asta
    - SpiderMonkey (Firefox)
    - Chakra (Edge)
    - V8 (Chrome)

- Pana in anul 2009 JavaScript rula doar in Browsere

- Incepand din 2009 a fost folosit V8 pentru a crea NodeJS 
    - (un motor care executa JavaAcript in afara browserelor)

- Deci NodeJS este un Mediu de executie (runtime environment)
    - similar cu un Browser

- NodeJS nu este 
    - un limbaj de programare
    - un framework

- NodeJS este un mediu de executie pentru limbajul JavaScript

- NodeJS si V8 sunt scrise in C++

- V8 este un motor care tranforma cod JavaScript in cod masina
    - V8 este open-source
    - poate rula standalone 
    - poate rula intr-o aplicatie C++ (embedded)

- Afisarea codului masina generat din JavaScript

```shell

> node --print_code
> var a = 100;

# se va afisa codul masina generat de V8

```


---

## Node versus Browser

- Obiectele la care avem acces in Node difera fata de cele din browser

- Nu avem obiectul `window` sau `document`
    - avem in schimb `global` sau `process`

- Nu putem manipula DOM-ul ca in Browser
    - dar putem manipula fisiere folosind modulul: `fs` 
    
- Deasemenea putem sa accesam date prin `http` 
    - sau sa ne conectam la bazele de date 

- Anumite module sunt comune, cum ar fi `setTimeout` sau `setInterval`

- Deci Node foloseste V8 precum Chrome si ne ofera in plus o colectie de module pe care nu le putem utiliza in Browser


---

## Arhitectura

- Non-blocking asynchronous architecture

- Node este potrivit pentru aplicatii cu multe operatii I/O 

- Este SingleThread
    - primeste un request si trimite procesarea intr-o coada (EventQueue)
    - cat timp se executa requestul (de ex. database query), un alt request poate fi interceptat si trimis spre procesare asincronica

- Node nu este potrivit pentru aplicatii CPU Intensive
    - atunci un request blocheaza thread-ul si alt request trebuie sa astepte
    - in schimb operatiile cu fisiere, baze de date sau http sunt tratate eficient de NodeJS


---

 
