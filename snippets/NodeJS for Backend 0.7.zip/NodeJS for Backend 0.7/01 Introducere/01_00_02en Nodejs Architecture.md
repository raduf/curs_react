###### _Material Curs: NodeJs for Backend  - Daniel Turcu_
---


# Nodejs Architecture - What is Google Chrome V8 Engine?

Node.js is a JavaScript run-time environment. There are different JavaScript engines including Rhino, JavaScriptCore, and SpiderMonkey. These engines follow the ECMAScript Standards. ECMAScript defines the standard for the scripting language. JavaScript is based on ECMAScript standards. These standards define how the language should work and what features it should have.

V8 is a runtime engine developed by Google for Chrome browser for JavaScript. It is the reason Node.js is fast and efficient. It is a program that converts Javascript code into lower level or machine code that microprocessors can understand.

The Chrome V8 engine :

* The V8 engine is written in C++ and used in Chrome and Nodejs.
* It implements ECMAScript as specified in ECMA-262.
* The V8 engine can run standalone we can embed it with our own C++ program.

Microprocessors are tiny machines that work with electrical signals and ultimately do the job. We give microprocessors the instructions. The instructions are in the language that microprocessors can interpret. Different microprocessors speak different languages. Some of the most common are IA-32, x86–64, MIPS, and ARM. These languages directly interact with the hardware so the code written in them is called machine code. Code that we write on our computers is converted or compiled into machine code. It consist of instructions that are performed at a particular piece of memory in your system at low level.

High level languages are abstracted from machine language. In the level of abstraction, JavaScript is abstracted from machine level. C/C++ are relatively much closer to the hardware and hence much faster than other high level languages.

V8 can run standalone, or can be embedded into any C++ application. It has hooks that allow you to write your own C++ code that you can make available to JavaScript. This essentially lets you to add features to JavaScript by embedding V8 into your C++ code so that your C++ code understands more than what the ECMAScript standard otherwise specifies.

So for example: print('hello world')is not a valid statement in Node.js. It will give error if we compile it. But we can add our own implementation of the print function in C++ on top of the V8 which is open source, thus, making the print function work natively. This allows the JavaScript to understand more than what the ECMAScript standard specifies the JavaScript should understand.

This is a powerful feature since C++ has more features as a programming language as compared to JavaScript, as it is much closer to hardware like dealing with files and folders on the hard drive. Node.js in itself is a C++ implementation of a V8 engine allowing server side programming and networking applications.

Let us now look at some of the open source code inside the engine. You can see the implementation of different functions such as Print and Read, which are natively not available in Node.js. Below, you can see the implementation of the Print function. Whenever the `print()` function is invoked in Node.js, it will create a callback and the function will be executed.

```js
// The callback that is invoked by v8 whenever the JavaScript 'print'
// function is called.  Prints its arguments on stdout separated by
// spaces and ending with a newline.
void Print(const v8::FunctionCallbackInfo<v8::Value>& args) {
  bool first = true;
  for (int i = 0; i < args.Length(); i++) {
    v8::HandleScope handle_scope(args.GetIsolate());
    if (first) {
      first = false;
    } else {
      printf(" ");
    }
    v8::String::Utf8Value str(args.GetIsolate(), args[i]);
    const char* cstr = ToCString(str);
    printf("%s", cstr);
  }
  printf("\n");
  fflush(stdout);
}
```

Similarly we can add our own implementation of different new functions in C++ inside V8 allowing it to be understood by Node.js. 
