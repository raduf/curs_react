# First Crud Operation in Nodejs

* check for the url `/`: `if (req.url === '/')`
* else send the file using `data` and a message that says correctly which Request Method is being used.
