
# 07_03x complete-crud-operations

- vom implementa POST, PUT si DELETE requests

- nu vom folosi ExpressJS inca

---

## POST, PUT si DELETE requests

```js
// server.js



```