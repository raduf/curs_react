
# 07_01_02x template-with-expressjs

- folosim template engine-ul `ejs` impreuna cu `ExpressJS`

---

## Instalam `express` si `ejs`

```shell
npm install express@4.16.2
npm install ejs@2.5.7
```

---

## Folosim ejs si express pentru a parsa folderul `.views`

- using express, no need to explicitly call `renderFile` to convert template files into HTML

- Express uses `res.render()` method for this purpose

- have to set a view engine and a views 
    - to let Express Server know about which template engine to use 
    - and where are template files stored.

```js
// index.js



```