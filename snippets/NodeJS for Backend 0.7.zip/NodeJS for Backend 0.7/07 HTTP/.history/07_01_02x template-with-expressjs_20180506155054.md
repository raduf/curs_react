
# 07_01_02x template-with-expressjs

- folosim template engine-ul `ejs` impreuna cu `ExpressJS`

---

## Instalam `express` si `ejs`

```shell
npm install express@4.16.2
npm install ejs@2.5.7
```

---

## Folosim ejs si express pentru a parsa folderul `.views`

- using express, no need to explicitly call `renderFile` to convert template files into HTML

- Express uses `res.render()` method for this purpose

- have to set a view engine and a views 
    - to let Express Server know about which template engine to use 
    - and where are template files stored.

```js
// index.js

const express = require('express');

const app = express();
const port = 3000;

app.set('views', './views');
app.set('view engine', 'ejs');

app.get('/', function(req, res) {
	res.render('index', { user: 'Michael Brown', title: 'Homepage' });
});

app.listen(port, () => {
	console.log(`Server running on port ${port}`);
});


```

