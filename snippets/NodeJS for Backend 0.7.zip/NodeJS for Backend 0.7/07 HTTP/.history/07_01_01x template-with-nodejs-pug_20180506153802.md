
# 07_01_01x template-with-nodejs-pug

---

## Instalare `pug`

`npm install pug`
`yarn add pug`

---

## 

```js
// app.js



```


- `pug.renderFile()` converts any Jade/Pug file into HTML.

---
