
# 07_03x complete-crud-operations

- vom implementa POST, PUT si DELETE requests

- nu vom folosi ExpressJS inca

---

## POST, PUT si DELETE requests

- vom testa rutele in Postman sau cu curl

```js
// server.js

...
else if (req.method === 'POST' && req.url === '/echo') {
		let body = [];
		req
			.on('data', chunk => {
				body.push(chunk);
			})
			.on('end', () => {
				body = Buffer.concat(body).toString();
				res.end(body);
			});
	} else if (req.method === 'PUT' && req.url === '/echo') {
		let body = [
			{ key: 'val' }
		];

		req
			.on('data', chunk => {
				body.push(chunk);
			})
			.on('end', () => {
				body = body.toString();
				res.end(body);
			});
	} else if (req.method === 'DELETE' && req.url === '/echo/key1') {
		let params = { key1: 'val' };
		let body = [
			{ key1: 'val' },
			{ key2: 'val' }
		];

		req
			.on('data', () => {
				body = body.filter(key => key !== params);
			})
			.on('end', () => {
				body = body.toString();
				res.end('Data Removed.');
			});
	} else {
		res.statusCode = 404;
		res.end();
    }
...

```

---

## Testam Rutele

> GET Request

```shell
 curl -X GET http://localhost:3000/
```

> POST Request

```shell
curl -d '{"key1":"value1", "key2":"value2"}' -H "Content-Type: application/json" -X POST http://localhost:3000/echo

# Output
{"key1":"value1", "key2":"value2"}
```

> PUT Request

```shell
curl -X PUT -H "Content-Type: application/json" -d '{"key":"value1"}' http://localhost:3000/echo

# Output
{"key":"value1"}
```

> Delete Request

```shell
curl -X DELETE http://localhost:3000/echo/key1

# Output
Data Removed.
```

You can also test these urls in POSTMAN or any other REST Client app.

---
