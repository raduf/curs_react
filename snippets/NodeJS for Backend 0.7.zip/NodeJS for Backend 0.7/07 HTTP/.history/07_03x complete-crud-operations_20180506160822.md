
# 07_03x complete-crud-operations

- vom implementa POST, PUT si DELETE requests

- nu vom folosi ExpressJS inca

---

## POST, PUT si DELETE requests

```js
// server.js

else if (req.method === 'POST' && req.url === '/echo') {
		let body = [];
		req
			.on('data', chunk => {
				body.push(chunk);
			})
			.on('end', () => {
				body = Buffer.concat(body).toString();
				res.end(body);
			});
	} else if (req.method === 'PUT' && req.url === '/echo') {
		let body = [
			{ key: 'val' }
		];

		req
			.on('data', chunk => {
				body.push(chunk);
			})
			.on('end', () => {
				body = body.toString();
				res.end(body);
			});
	} else if (req.method === 'DELETE' && req.url === '/echo/key1') {
		let params = { key1: 'val' };
		let body = [
			{ key1: 'val' },
			{ key2: 'val' }
		];

		req
			.on('data', () => {
				body = body.filter(key => key !== params);
			})
			.on('end', () => {
				body = body.toString();
				res.end('Data Removed.');
			});
	} else {
		res.statusCode = 404;
		res.end();
	}

```