
# 07_01_01x template-with-nodejs-pug

---

## Instalare `pug`

`npm install pug`
`yarn add pug`

---

## 