# Using Template Engine with Nodejs

- pug/jade template engine

* use `pug`: `npm install -S pug`
* `pug.renderFile()` converts any Jade/Pug file into HTML.
