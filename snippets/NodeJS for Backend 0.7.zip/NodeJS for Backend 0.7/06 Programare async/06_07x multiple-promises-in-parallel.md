
# 05_07x multiple-promises-in-parallel

- vom crea mai multe promisiuni ce vor rula in paralel

- in prima etapa toate trei sunt rezolvate cu succes 
    - doar cand toate sunt gata reactionam - `all`

- in al doilea caz, una este rejected 
    - chiar daca celelalte sunt rezolvate, nu primim rezultatele - `catch`

- in al treilea caz, ne intereseaza doar una dintre ele sa fie rezolvata
    - reactionam la prima terminata cu `race`
---

## Cream doua promisiuni resolved

```js
// app.js

const promise1 = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('Query database one...');
        resolve({id: 1, name: 'Project One'})
    }, +(Math.random()*2000).toFixed(0) )
});

const promise2 = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('Query database two...');
        resolve({id: 2, name: 'Project Two'})
    }, +(Math.random()*2000).toFixed(0) )
});

// 1 Toate promisiunile trebuiesc rezolvate inainte de a primi rezultatele
Promise.all([promise1, promise2])
    .then( result => console.log('All resolved: ', result) )
    .catch( err => console.log('All resolved - Eroare: ', err));

```

- raspunsul este:
```
Query database one...
Query database two...
All resolved:  [ { id: 1, name: 'Project One' },
  { id: 2, name: 'Project Two' } ]
``` 

---

## Adaugam o promisiune rejected

```js
// app.js

const promise3 = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('Query database three...');
        reject(new Error('Project three not found...'))
    }, +(Math.random()*2000).toFixed(0) )
});

// 1 Toate promisiunile trebuiesc rezolvate inainte de a primi rezultatele
// Promise.all([promise1, promise2])
//     .then( result => console.log('All resolved: ', result) )
//     .catch( err => console.log('All resolved - Eroare: ', err));

// 2 Avem o promisiune Rejected
Promise.all([promise1, promise3])
    .then( result => console.log('All resolved (una este rejected): ', result) )
    .catch( err => console.log('All resolved (una este rejected)- Eroare: ', err));

```

- raspunsul este:
    ` All resolved (una este rejected)- Eroare:  Error: Project three not found... `


---

##  Folosim race daca ne intereseaza doar prima promisiune rezolvata

- comentam promisiunea 3 (pentru ca acum nu este tratata)

- rulam de mai multe ori pentru a prinde si prima si a doua promisiune

```js
// app.js

...
// const promise3 = new Promise((resolve, reject) => {
//     setTimeout(() => {
//         console.log('Query database three...');
//         reject(new Error('Project three not found...'))
//     }, +(Math.random()*2000).toFixed(0) )
// });

...
Promise.race([promise1, promise2])
    .then( result => console.log('Prima rezolvata: ', result) )
    .catch( err => console.log('Prima rezolvata - Eroare: ', err));

```

- raspunsul este alternativ, in functie de valoarea Random a timeoutului fiecarei promisiuni

```
Query database two...
Prima rezolvata:  { id: 2, name: 'Project Two' }

# alternativ cu

Query database one...
Prima rezolvata:  { id: 1, name: 'Project One' }
```

---

## utilizarea `.race` iar una din promisiuni este rejected

- utilizam `race`, dar de data asta vom avea din cand in cand o eroare

- decomentam promisiunea 3

```js
// app.js

...
const promise3 = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('Query database three...');
        reject(new Error('Project three not found...'))
    }, +(Math.random()*2000).toFixed(0) )
});

...
// 3 Ne intereseaza prima promisiune rezolvata - una este Rejected
Promise.race([promise1, promise3])
    .then( result => console.log('Prima rezolvata (una este rejected): ', result) )
    .catch( err => console.log('Prima rezolvata (una este rejected) - Eroare: ', err));


```

- observam ca vom avea alternativ Success (promise1) versus Rejected (promise3)

```
Query database one...
Prima rezolvata (una este rejected):  { id: 1, name: 'Project One' }

# sau

Query database three...
Prima rezolvata (una este rejected) - Eroare:  Error: Project three not found...
```

