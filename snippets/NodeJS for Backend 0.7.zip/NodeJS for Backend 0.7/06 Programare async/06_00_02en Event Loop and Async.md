###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Event Loop and Async Non-blocking in Node.js

Node.js is single threaded. It supports concurrency through paradigms of event and callbacks. Since it is single threaded, most APIs provided within Node.js core are asynchronous. They follow a non-blocking Input/Output.

In a traditional Input/Output, when a request comes to a web server, it is assigned to a specific thread. For each concurrent connection, there is a new thread and the thread will continue to run until a response is sent for a particular request. This is a perfect example of Blocking I/O (Input/Output network operation) because when handling a particular request by a thread there will be some idle time when between operations are being performed (_such as retrieving a file, opening it, reading it, etc._). A single thread consumes memory. A longer running thread for each connection and sitting idly for some amount of time can consume a lot of memory. This is the reason why Node.js is built the non-blocking way.

Node.js follows an observer pattern (_also known as Reactor Pattern_). This pattern provides a handler (_also known as a callback function_) and associates it to each incoming I/O operation. These callbacks are the asynchronous functions. When Node.js starts, it initializes the Event Loop which offloads the operations to an operating system's kernel. These kernels are mutli-threaded as they can handle execution of multiple operations in the background. When one of the operations completes, the kernel lets Node.js know about it and the appropriate callback will be invoked.

All of these operations are queued in a poll which is also known as Event Queue. Any of these operations may proceed to more operations and these new operations are then again added to the Event Queue.

In summary, Event Loop will always be responsible for the execution of all the asynchronous callbacks registered for every event in the Event Queue. Other than I/O operations that are queued in the Event Queue or poll the other types of callbacks can also execute with the Event Loop. These other types are:

* Timers
* `process.nextTick()`

## Timers

In a timer function the callback associated with it will execute as early as possible in an Event Loop after the specified amount of time is passed which is mentioned while defining a timer function. Timer functions do not need to be imported via `require()` since all the methods are available globally just like in the browser JavaScript API but the behaviour of execution of these Timer functions in Node.js slightly differs that from the browser API.

There are different implementations of Timer functions available to us in Node.js.

**`setTimeout()`**
This function can be used to schedule code execution after a designated amount of milliseconds. This timer function executes by accepting the first argument another function that can be anonymous or separately declared. The second argument of the timer function is the amount of milliseconds delay defined. Additional arguments may also be included and these will be passed on to the function.

```javascript
function timerExample(arg) {
  console.log(`arg was => ${arg}`);
}

setTimeout(timerExample, 1000, 'execute');
```

The above function `timerExample()` will execute as close to 1000 milliseconds (or 1 second) as possible due to the call of `setTimeout()`. The Event Loop does not guarantee that the `setTimeout()` function will execute at the desired time. However, it does guarantees that it will not execute before the specified amount of time. This is because the other executing asynchronous/synchronous functions might push the execution of a `setTimeout()` function further.

**`setImmediate()`**
This function will execute the code at the end of the Event Loop cycle. This code will execute after any I/O operations in the current event loop and before any timers scheduled for the next event loop.

In `setImmediate()`, the first argument is going to be the the function to execute. Any other optional arguments can be passed to the function when it is executed.

```javascript
console.log('before immediate');

setImmediate(arg => {
  console.log(`executing immediate: ${arg}`);
}, 'during immediate');

console.log('after immediate');
```

The above snippet of code will output as:

```shell
before immediate
after immediate
executing immediate: during immediate
```

**`setInterval()`**

If there is a snippet of code that should execute multiple times, `setInterval()` can be used to execute that code. It takes a function as an argument that runs an infinite number of times. The delay between each iteration in given with a millisecond delay as the second argument. Just like `setTimeout()`, in this function the additional arguments can be added beyond the delay.

```javascript
function intervalFunc() {
  console.log('Interval Execution');
}

setInterval(intervalFunc, 1000);
```

To stop a `setInterval()` function from executing further, we can use another function that will perform this action: `clearInterval()`.

## process.nextTick()

The process object is one of the few global objects provided by the Node.js core API. It can be accessed from anywhere, thus its methods can also be accessed. There is a method called `process.nextTick()` that can be used in real-time applications to delay the execution of a an asynchronous operation until the next Iteration of an Event Loop.

An iteration of an Event Loop is called a tick. To manually schedule a callback function to be invoked in the next iteration of the Event Loop `process.nextTick()` is used. It takes a callback with time delay since it will be executing in the next iteration of the Event Loop.

The difference between the `process.nextTick()` and the timer functions is that former one is only available in Node.js and not in JavaScript's browser API.

```javascript
function callback() {
  console.log('Processed in next iteration');
}

process.nextTick(callback);

console.log('Processed in the first iteration');
```

You will definitely notice that the second console statement printed before the first statement associated with the function `callback()`.

```shell
Processed in the first iteration
Processed in next iteration
```

## Event Emitters

In Node.js events are associated with operations in Event Loop. For example, a TCP network server emits a _connect_ event every time a new client connects, or a stream can emit a _data_ event every time a new chunk of data is available to read. These objects in Node.js are called _event emitters_.

These objects that emit events are defined as the instances of the class `events.EventEmitter`. These objects reveal an `eventEmitter.on()` function that allows one or more functions to be attached to named events emitted.

When the `EventEmitter` object emits an event, the functions attached to that specific event are called synchronously.

```javascript
const events = require('events');
const eventEmitter = new events.EventEmitter();

eventEmitter.on('event', (a, b) => {
  const c = a + b;
  console.log('result: ', c);
});

eventEmitter.emit('event', 1, 2);
```

Using `eventEmitter.emit()` we can execute listener function with appropriate arguments. EventEmitter class offers a subscription based model to define callbacks, otherwise known as _pub/sub_ method. Please note that all the listeners attached to a particular event object are all synchronous functions and execute in the order they are registered or attached.
