###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Core Node.js API: HTTP, Streams, Buffers and FileSystem

In this tutorial, we are going to cover four main operational APIs available with Node.js core API.

* HTTP
* Buffer
* File System
* Streams

## HTTP

Node.js has a built in module called HTTP, which allows Node.js to transfer data over the Hyper Text Transfer Protocol. HTTP protocol is an application level protocol as it is the foundation of data communication over the internet. It is this module that helps us to create a Node.js based server.

### Creating the Server

To create a web server using the HTTP module, we need to require the module itself from Node.js API.

```javascript
const http = require('http');

const server = http.createServer((request, response) => {
  // rest of the server code
});
```

The `createServer()` provided by `http` module is what triggers a web server in any Node.js application. The callback function we are passing in `createServer()` is called once for every request incoming from the client. It accepts two arguments `request` and `response` objects. The request object is used to learn the details about the incoming request such as the URL, HTTP headers, etc. and response object is used to return data back to the client.

A basic HTTP server in Node.js will look like:

```javascript
const http = require('http');

const server = http
  .createServer((request, response) => {
    // http header + MIME type
    response.writeHead(200, { 'Content-Type': 'text/plain' });
    // send a response to the client
    response.write('Hello World!');
    // end the response
    response.end();
  })
  .listen(8080); //the server object listens on port 8080
```

The callback function associated with the `.createServer()` method begin by calling the `response.writeHead()` method. This method is used in with response object to send an HTTP status code and a collection of response headers back to the client. The status code indicates the result of the request. For example, a 404 error indicates that a page could not be found. Our example server returns the code 200, which indicates success in any web application.

The server returns a number of HTTP headers along with the status code. These HTTP headers define the parameters of the response object. Since we are not specifying these headers Node.js will implicitly take care of them and send them on behalf of our server side application. The above example server specifies only the `Content-Type` header. This particular header defines the MIME type of the response. In our case, it is `text/plain`. In the case of an HTML response, the MIME type is `text/html`.

Next, the server executes several calls to `response.write()`. These calls are used to write the HTML page. By default, UTF-8 character encoding is used. Lastly, the response.end() method is called that tells the server that the response headers and body is sent to the client and that the request has been fulfilled.

The `listen()` is the port number at which the Node.js server will listen to incoming requests.

**Note**: For secured communication over the internet, Node.js does have support for creating servers using HTTPS. HTTPS is an adaption of Hypertext Transfer Protocol but encrypted with a Transport Layer Security (TSL).

## Buffer

Binary is simply a set or a collection of `1` and `0`. Each number in a binary, each 1 and 0 in a set are called a _bit_. Computer converts the data to this binary format to store and perform operations. For example, the following are five different binaries:

`10, 01, 001, 1110, 00101011`

JavaScript does not have a byte type data in its core API. To handle binary data Node.js includes a binary buffer implementation with a global module called `Buffer`.

### Creating a Buffer

There are different ways you can create a buffer in Node.js. You can create an empty buffer by with a size of 10 bytes.

```javascript
const buf1 = Buffer.alloc(10);
```

From UTF-8-encoded strings, the creation is like this:

```javascript
const buf2 = Buffer.from('Hello World!');
```

There are different accepted encoding when creating a Buffer:

* ascii
* utf-8
* base64:
* latin1
* binary
* hex

There are three separate functions allocated in the Buffer API to use and create new buffers. In above examples we have seen `alloc()` and `from()`. The third one is `allocUnsafe()`.

```javascript
const buf3 = Buffer.allocUnsafe(10);
```

When returned, this function might contain old data that needs to be overwritten.

### Interactions with Buffer

There are different interactions that can be made with the Buffer API. We are going to cover most of them here. Let us start with converting a buffer to JSON.

```javascript
let bufferOne = Buffer.from('This is a buffer example.');
console.log(bufferOne);

// Output: <Buffer 54 68 69 73 20 69 73 20 61 20 62 75 66 66 65 72 20 65 78 61 6d 70 6c 65 2e>

let json = JSON.stringify(bufferOne);
console.log(json);

// Output: {"type": "Buffer", "data": [84,104,105,115,32,105,115,32,97,32,98,117,102,102,101,114,32,101,120,97,109,112,108,101,46]}
```

The JSON specifies that the type of object being transformed is a Buffer, and its data. Converting an empty buffer to JSON will show us that it contains nothing but zeros.

```javascript
const emptyBuf = Buffer.alloc(10);

emptyBuf.toJSON();

// Output: { "type": "Buffer", "data": [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ] }
```

Do notice that, Buffer API also provides a direct function `toJSON()` to convert a buffer into a JSON object. To examine the size of a buffer, we can use `length` method.

```javascript
emptyBuf.length;
// Output: 10
```

Now let us convert buffer to a readable string, in our case, the utf-8 encoded.

```javascript
console.log(bufferOne.toString('utf8'));

// Output: This is a buffer example.
```

`.toString()` by default converts a buffer to a utf-8 format string. This is how you decode a buffer. If you specify an encoding you can convert the buffer to another encoding

```javascript
console.log(bufferOne.toString('base64'));
```

## File System

Node.js provides an API to communicate with a file system of a computer. File I/O is provided by simple wrappers around standard POSIX functions. It is represented by `fs` and to use this module we have to require it with `require('fs')`. All of its methods have asynchronous and synchronous forms for the common use of the module:

* Reading Files
* Creating Files
* Deleting Files
* Updating Files
* Renaming Files

### File API

**Opening a File**

To read or manipulate files in a system, we first need access to them. This access is provided by two things, the path to the file and `open` function which is used to open a file.

```javascript
fs.open('/path/to/file', 'r', (err, fd) => {
  // ...
});
```

The first argument is the path to the file, the second argument is is a flag that determines the mode with which file should open. In our case, `r` indicates that the file should be open as in a read-only mode. There are other modes that we will discuss later. Lastly, is a callback function which when invoked provides a file descriptor `fd` which is used for manipulation of the file.

The other flags that you can use a second argument are:

* `r+`: for reading and writing
* `w`: create a file for writing
* `w+`: for reading and writing, and also creates the file if it does not exist.
* `a`: for appending the file, will begin appending at the last position of a character.

**Reading a File**

Once the file is open, you can read the entire content of the file asynchronously.

```javascript
fs.readFile('/path/to/file', (err, data) => {
  console.log(data);
});
```

The callback possesses two arguments in which `data` contains the content of the file. If character encoding is specified, a raw buffer is returned. To read the file in human readable form we have to mention `utf-8` character encoding as the second argument.

```javascript
fs.readFile('/path/to/file', 'utf-8', (err, data) => {
  console.log(data);
});
```

**Writing in a File**

To write in a file that is previously opened, we can make use of `fs.writeFile` method. This function asynchronously writes the data to a file mentioned as the second argument. It will replace any data that already exists in the file. `data` can be sent as a string or a buffer.

```javascript
fs.writeFile('path/to/file', 'New Content', err => {
  if (err) {
    console.log(error);
  }
});
```

**Updating a File**

`fs.appendFile()` is the method that can be used to update the file. Behind the scene it uses flag `a` as it does replace the data that already exists in the file but it starts writing in the file from the last character position.

```javascript
fs.appendFile('path/to/file', 'Add this content too', err => {
  if (err) {
    console.log(err);
  }
});
```

The `error` clause of our callback only runs when there is an error in accessing or manipulating the file.

**Deleting a File**

To delete a file using `fs` module, we make use of `fs.unlink()`.

```javascript
fs.unlink('path/to/file', error => {
  if (error) {
    console.log(error);
  }
  console.log('File Deleted!');
});
```

If there is a success in deleting the file specified, the last console statement in the callback will print.

**Renaming a File**

`fs` method can be highly useful for a use case where you are manipulation files to some extent, with your application. It also provides a method that is used to rename an existing filename.

```javascript
fs.rename('oldFilename.txt', 'newFilename.txt', err => {
  if (error) {
    console.log(error);
  }
  console.log('Renamed!');
});
```

## Streams

Streams are available in Node.js core API as objects that allow the data to read or write in a continuous way. Basically, a stream does that in chunks in comparison to buffer which does its bit by bit, thus making it a slow process.

There are four types of streams available:

* Readable (streams from which data is read)
* Writable (streams to which data is written)
* Duplex (streams that are both Readable and Writable)
* Transform (Duplex Streams that can modify data as it is read and written)

Each available type has several methods associated. Some of the common ones are:

* data (this runs when data is available)
* end (this gets triggered when there is no data left to read)
* error (this runs when there is an error either receiving or writing data)

### Pipe

In programming, the concept of `pipe` is not new. Unix based systems have been pragmatically using it since the 1970s. What does a Pipe do? A `pipe` generally connects the source and the destination. It passes the output of one function as the input of another function.

In Node.js, `pipe` is used the same way, to pair inputs and outputs of different operations. `pipe()` is available as a function that takes a readable source stream and attaches the output to a destination stream. The general syntax can be represented as:

```javascript
src.pipe(dest);
```

Multiple `pipe()` functions can also be chained together.

```javascript
a.pipe(b).pipe(c);

// which is equivalent to

a.pipe(b);
b.pipe(c);
```

### Readable Streams

Streams that produce data that can be attached as the input to a writable stream is known as a Readable stream. To create a readable stream:

```javascript
const { Readable } = require('stream');

const readable = new Readable();

readable.on('data', chunk => {
  console.log(`Received ${chunk.length} bytes of data.`);
});
readable.on('end', () => {
  console.log('There will be no more data.');
});
```

### Writable Stream

This is the type of a stream that you can `pipe()` the data to from a readable source. To create a writable stream, we have a constructor approach. We create an object from it and pass a number of options. The method takes three arguments:

* chunk: a buffer
* encoding: to convert data to human readable form
* callback: a function that is called when the data is done processing from the chunk

```javascript
const { Writable } = require('stream');
const writable = new Writable({
  write(chunk, encoding, callback) {
    console.log(chunk.toString());
    callback();
  }
});

process.stdin.pipe(writable);
```

### Duplex Streams

Duplex streams help us to implement both readable and writable streams at the same time.

```javascript
const { Duplex } = require('stream');

const inoutStream = new Duplex({
  write(chunk, encoding, callback) {
    console.log(chunk.toString());
    callback();
  },

  read(size) {
    this.push(String.fromCharCode(this.currentCharCode++));
    if (this.currentCharCode > 90) {
      this.push(null);
    }
  }
});

inoutStream.currentCharCode = 65;
process.stdin.pipe(inoutStream).pipe(process.stdout);
```

The `stdin` stream pipes the readable data into the duplex stream. The `stdout` helps us to see the data. The readable and writable parts of a duplex stream operate completely independent of each other.

### Transform Stream

This type of stream is more of an advanced version of the duplex stream.

```javascript
const { Transform } = require('stream');

const upperCaseTr = new Transform({
  transform(chunk, encoding, callback) {
    this.push(chunk.toString().toUpperCase());
    callback();
  }
});

process.stdin.pipe(upperCaseTr).pipe(process.stdout);
```

The data we are consuming is same as the previous example of the duplex stream. The thing to notice here is that `transform()` does not require implementation of `read` or `write` methods. It combines both the methods itself.

### Why use Streams?

Since Node.js is asynchronous so interacting by passing callbacks to functions with disk and network. An example given below reads the data from a file on the disk and responds it to over the network request from client.

```javascript
const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  fs.readFile('data.txt', (err, data) => {
    res.end(data);
  });
});
server.listen(8000);
```

The above snippet of code will work but the entire data from the file will first go into the memory for every request before writing the result back to the client request. If the file we are reading is too large, this can become a very heavy and expensive server call as it will consume a lot of memory for the process to advance. The user experience on the client side will also suffer from delay.

In this case, if we use streams, the data will be send to the client request as one chunk at a time as soon as they received from the disk.

```javascript
const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  const stream = fs.createReadStream('data.txt');
  stream.pipe(res);
});
server.listen(8000);
```

The `pipe()` here takes care of writing or in our case, sending the data with response object and once all the data is read from the file, to close the connection.

Note: `process.stdin` and `process.stdout` are build in streams in the global `process` object provided by Node.js API.
