###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

## What are Callbacks?

- name of a convention for using JavaScript functions 

- functions that use callbacks can take some time to produce a result

- The syntax:

```javascript
function callback(error, payload) {
  if (error) {
    console.error(error);
  } else {
    // use payload data
  }
}
```

- there is a possibility that due some reason, the operation might not complete. 
    - error clause in callback function will help us know

- run a normal sync function:

```javascript
const result = addTwoNumbers(3, 8);
console.log(result);
// 10 gets printed
```

- functions that are asynchronous and use callbacks don't return anything when they are used

```javascript
let file = downloadFile('http://abcdef.com/bookslist.pdf');
// file is 'undefined'!
```

- Loading a file can take a significant amount of time. 

- If the function we are executing is synchronous, the application will be blocked till the file is download.

 - We send a callback function to the existing function to make it asynchronous.

```javascript
function handleFileDownloading(error, file) {
  if (error) {
    console.error('Network error!');
  } else {
    console.log('Download Finished');
  }
}

downloadFile('http://abcdef.com/bookslist.pdf', handleFileDownloading);

console.log('Download Started');
```

- the console statement `Download Finished` is declared before the `Download Started`, yet the vice versa is happening. 

- `Download Finished` console statement is inside the callback function, it will only execute when the callback function is invoked. 

---

### Callback Hell


```javascript
fs.readdir(source, function(err, files) {
  if (err) {
    console.log('Error finding files: ' + err);
  } else {
    files.forEach(function(filename, fileIndex) {
      console.log(filename);
      gm(source + filename).size(function(err, values) {
        if (err) {
          console.log('Error identifying file size: ' + err);
        } else {
          console.log(filename + ' : ' + values);
          aspect = values.width / values.height;
          widths.forEach(
            function(width, widthIndex) {
              height = Math.round(width / aspect);
              console.log(
                'resizing ' + filename + 'to ' + height + 'x' + height
              );
              this.resize(width, height).write(
                dest + 'w' + width + '_' + filename,
                function(err) {
                  if (err) console.log('Error writing file: ' + err);
                }
              );
            }.bind(this)
          );
        }
      });
    });
  }
});
```

- This is known as _callback hell_. 
- a pyramid shape makes the source code hard to read and debug 

> The reason callback hells exist is not that of callbacks but because ***developers are often tempted to write a program where execution happens visually from top to bottom***.

> If we keep our functions modularized and name instead of using anonymous functions, it will be easier for developers to understand the code as well as the flow of the whole code. 

- modularized code also increases code reusability. 

- Reusable callback functions can be associated as many times as needed.

---

### Other Ways to Avoid Callback Hells

**Promises**
- are a way to write async code that still appears as though it is executing in a top-down way, 


**Generators**
Generators let you 'pause' individual functions without pausing the state of the whole program

**Async/Await**
Async/Await functions are a proposed ES7 feature that will further wrap generators and promises in a higher level syntax.


---

## Promises

- an object that wraps an asynchronous operation and notifies when it’s done. 

- This sounds exactly like callbacks, but the important differences are in the usage of Promises. 

- Instead of providing a callback, a promise has its own methods which you call to tell the promise what will happen when it is successful or when it fails. 

- The methods a promise provides are 
    - `then()` for when a successful result is available 
    - `catch()` for when something an error occurs.

- syntax of a typical promise function looks like this:

```javascript
asyncOperation(parameters)
  .then(result => {
    // Do something with the result
  })
  .catch(error => {
    // handle error here
  });
```

- `then()` and `catch()` functions are chained together

- `then()` part of a promise based function can be chained together when needed. 
    - similar to nesting callback functions without getting the pyramid looking source code

```javascript
axios.get('https://abc.com/')
  .then((response) => {
    // response is the result here for first request
    // after some operations, it makes another call to the API
    axios.get('https://abc.com/users)
  })
  .then((response) => {
    // this response is the result of second request
  })
  .catch((error) => {
    // handle error
  });
```

- handle the error only once using `catch()`. 

- if we omit `.catch()` when running in Node.js, an automated warning can be seen in logs that starts with `UnhandledPromiseRejectionWarning`

