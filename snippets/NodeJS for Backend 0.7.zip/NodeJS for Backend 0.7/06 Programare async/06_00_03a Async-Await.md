###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Async Await in Node.js

- `async/await` is a semantic that allows working with asynchronous functions gracefully. 

- it is built on top of a previously exisiting way of handling asynchronous functions, Promises, 

- the new syntax is compatible with all existing promise based libraries and APIs.

- promises can require a lot of chaining of `then()` methods

---

> advantages this new way of writing _promises_ posses:

* Debugging a callback could be tricky, fortunately, not in the case of `async/await`

* Converting a promise based existing function is easy

* the flow of the code will be more top to down rather than nested


---

## What is async?

- `async` is a keyword to declare an asynchronous function. 

- It automatically transforms a regular function into a promise without the need of `then()/catch()`. 

```javascript
async function funcName() {...}
```

- It returns a promise regardless of whatever value the function returns. 

- It also enables the use of `await` which helps to control the returned promise.

---

## What is await?

- `await` is used to pause the execution of a promise based function. 

- can only be used inside an `async` function, 

- it is placed in front of a promise call


```javascript
const result = await someAsyncCall();
```

---

## A Basic Example

Putting together the two, we get:

```javascript
const fetchContent = async () => {
  let json = await fetch('/home');
  console.log(json);

  return json;
};
```

- example in which we convert a complete promised based function that is using `axios` to fetch data from an API into `async await` one

```javascript
// promise based API call
const getInfo = () =>
  axios.get('/users')
    .then(users => {
      console.log(users)
    })
    .then(() => getGroups())
    .then(groups => {
      console.log(groups)
    })
    .then(() => getFavorites())
    .then(favorites => {
      console.log(favorites)
      return 'all done'
    }

getInfo()

// async/await based API call

const getInfo = async () => {
 console.log(await axios.get('/users'))
 console.log(await getGroups())
 console.log(await getFavorites())
 return 'all done';
}

getInfo();
```

---

## Error Handling in async/await

In `async/await` we use `try/catch` blocks that exist in JavaScript already.

```javascript
// promise based

function asyncTask() {
  return functionA()
    .then(valueA => functionB(valueA))
    .then(valueB => functionC(valueB))
    .then(valueC => functionD(valueC))
    .catch(err => logger.error(err));
}

// async/await based

async function asyncTask() {
  try {
    const valueA = await functionA();
    const valueB = await functionB(valueA);
    const valueC = await functionC(valueB);
    return await functionD(valueC);
  } catch (err) {
    logger.error(err);
  }
}
```

---

## async/await in Express

- we will re-write a route to get information of all the todo items from the database.

```javascript
router.get('/', async (req, res, next) => {
  const { item } = req.body;

  try {
    const allItems = await db.findAll({});
    res.json({
      data: allItems
    });
  } catch (e) {
    res.json({ error: e });
  }
});
```

