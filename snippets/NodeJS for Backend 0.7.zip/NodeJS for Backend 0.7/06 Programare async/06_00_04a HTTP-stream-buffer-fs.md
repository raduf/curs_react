###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Core Node.js API: HTTP, Streams, Buffers and FileSystem

- main operational APIs available with Node.js core API.

* HTTP
* Buffer
* File System
* Streams


---
## HTTP

- built in module 

- allows Node.js to transfer data over the Hyper Text Transfer Protocol. 

- HTTP protocol is an application level protocol
  - it is the foundation of data communication over the internet. 
  
- HTTP module helps us to create a Node.js based server.

---

### Creating the Server

To create a web server using the HTTP module, we need to require the module itself from Node.js API.

```javascript
const http = require('http');

const server = http.createServer((request, response) => {
  // rest of the server code
});
```

- The `createServer()` triggers a web server in any Node.js application. 

- The callback function we are passing in `createServer()` is called once for every request incoming from the client. 

- It accepts two arguments `request` and `response` objects. 
  - `request` object is used to learn the details about the incoming request 
    - URL, 
    - HTTP headers, 
    - etc. 
  - `response` object is used to return data back to the client.

A basic HTTP server in Node.js:

```javascript
const http = require('http');

const server = http
  .createServer((request, response) => {
    // http header + MIME type
    response.writeHead(200, { 'Content-Type': 'text/plain' });
    // send a response to the client
    response.write('Hello World!');
    // end the response
    response.end();
  })
  .listen(8080); //the server object listens on port 8080
```

- `response.writeHead()` is used to send an HTTP status code 
  - and other response headers back to the client. 

- status code indicates the result of the request. 
  - a 404 status indicates that a page could not be found. 
  - code 200 indicates success.

- The server returns a number of HTTP headers along with the status code. 

- These HTTP headers define the parameters of the response object. 

- If we are not specifying other headers Node.js will implicitly take care of them and send them

- The above example server specifies only the `Content-Type` header. 
  - This particular header defines the MIME type of the response. 
    - In the case of an HTML response, the MIME type is `text/html`.

- the server executes several calls to `response.write()`. 
  - These calls are used to write the page. 
  - By default, `UTF-8 character encoding` is used. 
  
- `response.end()` tells the server to sent the response to the client

- `listen()` specifies the port number at which the Node.js server will listen to incoming requests.

> For secured communication over the internet, Node.js does have support for creating servers using HTTPS. 

- HTTPS is an adaption of Hypertext Transfer Protocol but encrypted with a Transport Layer Security (TSL).


---

## Buffer

- Binary is simply a set or a collection of `1` and `0`. 

- Each number in a binary, each 1 and 0 in a set are called a _bit_. 

- Computer converts the data to this binary format to store and perform operations. 

`10, 01, 001, 1110, 00101011`

- JavaScript does not have a byte type data in its core API. 

- To handle binary data Node.js includes a binary buffer implementation with a global module called `Buffer`.

---

> javascript, while great with unicode-encoded strings, does not handle straight binary data very well. This is fine on the browser, where most data is in the form of strings

> Node.js servers have to also deal with TCP streams and reading and writing to the filesystem, both which make it necessary to deal with purely binary streams of data.

> Each buffer corresponds to some raw memory allocated outside V8

---

### Creating a Buffer

You can create an empty buffer with a size of 10 bytes:

```javascript
const buf1 = Buffer.alloc(10);
```

- From UTF-8-encoded strings, the creation is like this:

```javascript
const buf2 = Buffer.from('Hello World!');
```

There are different accepted encoding when creating a Buffer:

* ascii
* utf-8
* base64:
* latin1
* binary
* hex

- three functions in the Buffer API to use and create new buffers. 
  - `alloc()`, `from()` and `allocUnsafe()`.

```javascript
const buf3 = Buffer.allocUnsafe(10);
```

- When returned, this function might contain old data that needs to be overwritten.

---

### Interactions with Buffer

There are different interactions that can be made with the Buffer API. 

- converting a buffer to JSON.

```javascript
let bufferOne = Buffer.from('This is a buffer example.');
console.log(bufferOne);

// Output: <Buffer 54 68 69 73 20 69 73 20 61 20 62 75 66 66 65 72 20 65 78 61 6d 70 6c 65 2e>

let json = JSON.stringify(bufferOne);
console.log(json);

// Output: {"type": "Buffer", "data": [84,104,105,115,32,105,115,32,97,32,98,117,102,102,101,114,32,101,120,97,109,112,108,101,46]}
```

- Converting an empty buffer to JSON:

```javascript
const emptyBuf = Buffer.alloc(10);

emptyBuf.toJSON();

// Output: { "type": "Buffer", "data": [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ] }
```

- Buffer API provides a direct function `toJSON()` to convert a buffer into a JSON object.

- To examine the size of a buffer, we can use `length` method:

```javascript
emptyBuf.length;
// Output: 10
```

- Convert buffer to a readable string:

```javascript
console.log(bufferOne.toString('utf8'));

// Output: This is a buffer example.
```

`.toString()` by default converts a buffer to a utf-8 format string. 
  - This is how we decode a buffer. 
  - If you specify an encoding you can convert the buffer to another encoding

```javascript
console.log(bufferOne.toString('base64'));
```

---

## File System


- Node.js provides an API to communicate with a file system of a computer. 

- File I/O is provided by simple wrappers around standard POSIX functions. 

- It is represented by `fs` 
  - we have to require it with `require('fs')`. 
  
- All of its methods have asynchronous and synchronous variants:

* Reading Files
* Creating Files
* Deleting Files
* Updating Files
* Renaming Files

> _The Portable Operating System Interface (POSIX) is a family of standards for maintaining compatibility between operating systems. POSIX defines the API, along with command line shells and utility interfaces, for software compatibility with variants of Unix and other operating systems._

---

### File API

**Opening a File**

- To read or manipulate files in a system, we first need access to them.

- This access is provided by two things, 
  - the path to the file 
  - `open` function which is used to open a file.

```javascript
fs.open('/path/to/file', 'r', (err, fd) => {
  // ...
});
```

- The first argument is the path to the file

- the second argument is is a flag that determines the mode with which file should open. 
  - `r` indicates that the file should be open in a read-only mode. 
  
- Last callback function provides a file descriptor `fd` 
    - `fd` is used to manipulate the file.

---

The other flags that you can use a second argument:

* `r+`: for reading and writing
* `w`: create a file for writing
* `w+`: for reading and writing, and also creates the file if it does not exist.
* `a`: for appending the file, will begin appending at the last position of a character.

---

**Reading a File**

Once the file is open, you can read the entire content of the file asynchronously.

```javascript
fs.readFile('/path/to/file', (err, data) => {
  console.log(data);
});
```

- `data` has the content of the file. 

- If character encoding is specified, a raw buffer is returned. 

> To read the file in human readable form we have to mention `utf-8` character encoding as the second argument.

```javascript
fs.readFile('/path/to/file', 'utf-8', (err, data) => {
  console.log(data);
});
```

---

**Writing in a File**

- To write in a file that is previously opened use `fs.writeFile`

- `fs.writeFile` asynchronously writes the data to a file mentioned as the second argument. 

- `fs.writeFile` will replace any data that already exists in the file. 

- `data` can be sent as a string or a buffer.

```javascript
fs.writeFile('path/to/file', 'New Content', err => {
  if (err) {
    console.log(error);
  }
});
```

---

**Updating a File**

- `fs.appendFile()` can be used to update the file. 

- it starts writing in the file from the last character position.

```javascript
fs.appendFile('path/to/file', 'Add this content too', err => {
  if (err) {
    console.log(err);
  }
});
```

> The `error` clause of our callback only runs when there is an error in accessing or manipulating the file.

---

**Deleting a File**

- To delete a file we make use of `fs.unlink()`.

```javascript
fs.unlink('path/to/file', error => {
  if (error) {
    console.log(error);
  }
  console.log('File Deleted!');
});
```

---

**Renaming a File**


```javascript
fs.rename('oldFilename.txt', 'newFilename.txt', err => {
  if (error) {
    console.log(error);
  }
  console.log('Renamed!');
});
```

---

## Streams

- Streams are objects that allow to read or write data in a continuous way. 

- a stream does that in chunks in comparison to buffer which does its bit by bit (thus making it a slow process)

There are four types of streams available:

* Readable (streams from which data is read)
* Writable (streams to which data is written)
* Duplex (streams that are both Readable and Writable)
* Transform (Duplex Streams that can modify data as it is read and written)

Each available type has several methods associated. Some of the common ones are:

* data (this runs when data is available)
* end (this gets triggered when there is no data left to read)
* error (this runs when there is an error either receiving or writing data)

---

### Pipe

-  A `pipe` generally connects the source and the destination. 

- passes the output of one function as the input of another function.

- In Node.js, `pipe` is used the same way, to pair inputs and outputs of different operations. 

- `pipe()` is available as a function that takes a readable source stream and attaches the output to a destination stream. 

- The general syntax:

```javascript
src.pipe(dest);
```

Multiple `pipe()` functions can be chained

```javascript
a.pipe(b).pipe(c);

// which is equivalent to

a.pipe(b);
b.pipe(c);
```

---

### Readable Streams

Streams that produce data that can be attached as the input to a writable stream

To create a readable stream:

```javascript
const { Readable } = require('stream');

const readable = new Readable();

readable.on('data', chunk => {
  console.log(`Received ${chunk.length} bytes of data.`);
});
readable.on('end', () => {
  console.log('There will be no more data.');
});
```

---

### Writable Stream

- a stream that you can `pipe()` the data to 
    - from a readable source. 


```javascript
const { Writable } = require('stream');
const writable = new Writable({
  write(chunk, encoding, callback) {
    console.log(chunk.toString());
    callback();
  }
});

process.stdin.pipe(writable);
```


* chunk: a buffer
* encoding: to convert data to human readable form
* callback: a function that is called when the data is done processing from the chunk

---

### Duplex Streams

- help us to implement both readable and writable streams at the same time.

```javascript
const { Duplex } = require('stream');

const inoutStream = new Duplex({
  write(chunk, encoding, callback) {
    console.log(chunk.toString());
    callback();
  },

  read(size) {
    this.push(String.fromCharCode(this.currentCharCode++));
    if (this.currentCharCode > 90) {
      this.push(null);
    }
  }
});

inoutStream.currentCharCode = 65;
process.stdin.pipe(inoutStream).pipe(process.stdout);
```

- The `stdin` stream pipes the readable data into the duplex stream. 

- The `stdout` helps us to see the data. 

- The readable and writable parts of a duplex stream operate completely independent of each other.

--

### Transform Stream

This type of stream is more of an advanced version of the duplex stream.

```javascript
const { Transform } = require('stream');

const upperCaseTr = new Transform({
  transform(chunk, encoding, callback) {
    this.push(chunk.toString().toUpperCase());
    callback();
  }
});

process.stdin.pipe(upperCaseTr).pipe(process.stdout);
```

- `transform()` does not require implementation of `read` or `write` methods. 

- It combines both the methods itself.


> `process.stdin` and `process.stdout` are build in streams in the global `process` object provided by Node.js API.

---

### Why use Streams?

- reads the data from a file on the disk and responds it to over the network request from client.

```javascript
const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  fs.readFile('data.txt', (err, data) => {
    res.end(data);
  });
});
server.listen(8000);
```

---
- The above snippet of code will work but the entire data from the file will first go into the memory 
  - then will write the result back to the client request. 

- If the file we are reading is too large, this can become a very heavy

- it will consume a lot of memory for the process to advance. 

- The user experience on the client side will also suffer from delay.

---

> In this case, if we use streams, the data will be send to the client request as one chunk at a time as soon as they received from the disk.

```javascript
const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  const stream = fs.createReadStream('data.txt');
  stream.pipe(res);
});
server.listen(8000);
```

- `pipe()` takes care of writing 
  - in our case, sending the data with response object 
  - once all the data is read from the file, `pipe()` close the connection.

---

