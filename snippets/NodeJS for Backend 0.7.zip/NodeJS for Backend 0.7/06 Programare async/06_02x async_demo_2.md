
# async_demo_2

- nu putem sa utilizam functiile `async` precum instructiunile `sync`

---

## Utilizam o functie async si afisam rezultatul returnat

```js
// app.js


const currentProject = getCurrentProject(2);
console.log(currentProject);

function getCurrentProject(userid) {
    // simulam databse query
    setTimeout(()=>{
        console.log('Running query...');
        return { id: 1, name: 'Project One', userid: userid};
    }, 1500);

    return { id: 10, name: 'Project Ten', userid: userid}
}


```
- observam ca rezultatul afisat nu este cel din codul `async`
- daca ultimul `return` nu ar fi, functia ar returna `undefined`

--- 