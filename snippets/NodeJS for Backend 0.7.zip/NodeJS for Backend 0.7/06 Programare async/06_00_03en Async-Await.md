###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

# Async Await in Node.js

The recent addition of `async/await` in JavaScript is a semantic that allows working with asynchronous functions gracefully. Since it is built on top of a previously exisiting way of handling asynchronous functions, Promises, the new syntax is compatible with all existing promise based libraries and APIs.

When promises were introduced in JavaScript's core API, they were a huge improvement and provided betterment in handling asynchronous functions than a callback. But they do require a lot of chaining of `then()` methods which can turn out to be a mess especially when you are querying a database using a promise based ORM module. The introduction to `async/await` methodology is for the simple reason that they help to keep code precise. Other major advantages this new way of writing _promises_ posses:

* Debugging a callback could be tricky, fortunately, not in the case of `async/await`
* Converting a promise based existing function into this is easy
* the flow of the code will be more top to down rather than nested

Since we have seen the need of `async/await` pattern, now, let us learn what they exactly are and how to use them.

## What is async?

`async` is a keyword to declare an asynchronous function. It automatically transforms a regular function into a promise without the need of `then()/catch()`. A typical syntax of an `async` function will look this:

```javascript
async function funcName() {...}
```

It returns a promise regardless of whatever value the function returns. It also enables the use of `await` which helps to control the returned promise.

## What is await?

`await` is used to pause the execution of a promise based function. Since it can be used only inside an `async` function, it is placed in front of a promise call, until that promise call finishes and returns a result. General syntax:

```javascript
const result = await someAsyncCall();
```

## A Basic Example

Putting together the two, we get:

```javascript
const fetchContent = async () => {
  let json = await fetch('/home');
  console.log(json);

  return json;
};
```

We start a function by declaring it with `async` keyword. The `await` keyword is then placed in front of `fetch()` method which promised based library that makes use of `then()/cathc()` and is available in browser's JavaScript API. The asynchronous `fetch()` executes until the result is back.

Let us take one more example in which we convert a complete promised based function that is using `axios` to fetch data from an API into `async await` one. You will clearly notice the difference and how much less code is there to write.

```javascript
// promise based API call
const getInfo = () =>
  axios.get('/users')
    .then(users => {
      console.log(users)
    })
    .then(() => getGroups())
    .then(groups => {
      console.log(groups)
    })
    .then(() => getFavorites())
    .then(favorites => {
      console.log(favorites)
      return 'all done'
    }

getInfo()

// async/await based API call

const getInfo = async () => {
 console.log(await axios.get('/users'))
 console.log(await getGroups())
 console.log(await getFavorites())
 return 'all done';
}

getInfo();
```

## Error Handling in async/await

Remember, how we used to attach a single `catch()` method at the end of the chain in a promise based function? In `async/await` it is similar. We use `try/catch` blocks that exist in JavaScript already.

```javascript
// promise based

function asyncTask() {
  return functionA()
    .then(valueA => functionB(valueA))
    .then(valueB => functionC(valueB))
    .then(valueC => functionD(valueC))
    .catch(err => logger.error(err));
}

// async/await based

async function asyncTask() {
  try {
    const valueA = await functionA();
    const valueB = await functionB(valueA);
    const valueC = await functionC(valueB);
    return await functionD(valueC);
  } catch (err) {
    logger.error(err);
  }
}
```

In many programming languages, it is practiced and considered that `try/catch` are the perfect way to handle errors. Well, in JavaScript you are not far behind. The `catch()` method handle errors provoked by the awaited asynchronous calls or any other failing code that might occur inside try block.

## async/await in Express

In the example below, we will re-write a route to get information of all the todo items from the database.

```javascript
router.get('/', async (req, res, next) => {
  const { item } = req.body;

  try {
    const allItems = await db.findAll({});
    res.json({
      data: allItems
    });
  } catch (e) {
    res.json({ error: e });
  }
});
```

See how simple it is! We just have to use the try-catch block instead of `then/catch` methods.
