
const { Duplex } = require('stream');

const inoutStream = new Duplex({
  write(chunk, encoding, callback) {
    let arr = chunk.toString().split(',').map( item => +item);
    const reducer = (acc, currentValue) => acc + currentValue;
    console.log(arr.reduce(reducer));
    callback();
  },

  read(size) {
    this.push(String.fromCharCode(this.currentCharCode++) + ',');
    if (this.currentCharCode > 57) {
      this.push(null);
    }
  }
});

inoutStream.currentCharCode = 48; // suma de la 0 la 9
process.stdin.pipe(inoutStream).pipe(process.stdout);

