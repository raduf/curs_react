
const { Duplex } = require('stream');

const inoutStream = new Duplex({
  write(chunk, encoding, callback) {
    let arr = chunk.toString().split(',').map( item => +item);
    const reducer = (acc, currentValue) => acc + currentValue;
    console.log(arr.reduce(reducer));
    callback();
  },

  read(size) {
    this.push(this.message);
    this.push(null);
  }
});

inoutStream.message = 'Introduceti un sir de numere despartite cu `,`: 1,2,7'
process.stdin.pipe(inoutStream).pipe(process.stdout);

