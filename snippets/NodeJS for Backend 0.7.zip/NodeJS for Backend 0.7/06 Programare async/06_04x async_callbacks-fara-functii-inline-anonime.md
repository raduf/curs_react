
# 05_04Z_async_callbacks-fara-functii-inline-anonime


---

## Rescriem functiile callback fara functii anonime inline

- comentam codul imbricat de la // 2

- atentie la printTask: `console.log()` nu mai stie de `project.name`
    - rescriem mesajul in: `Proiectul curent pentru userul 2:`

```js
// app.js

...

getCurrentProject(2, printProjects);

function printProjects(project) {
    console.log('Proiectul curent pentru userul 2: ', project);
    console.log('Start getting tasks...');
    getTasksByProjectId(project.id, printTasks);
}

function printTasks(tasks) {
    console.log(`Proiectul curent are task-urile: `, tasks);
    let taskIds = tasks.map(task => task.id);
    getTasksHistory(taskIds, printActions )
}

function printActions(actions) {
    console.log('History: ', actions)
}

```

