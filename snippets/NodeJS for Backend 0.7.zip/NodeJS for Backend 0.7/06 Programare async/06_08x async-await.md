
# 05_08x async-await

- vom folosi `async/await` pattern impreuna cu promises

- pattern-ul `async/await` ne permite sa folosim cod `async` precum folosim codul `sync`

---

## Folosim await impreuna cu promisiunile

- comentam codul vechi (cel care foloseste `.then()`)

```js
// app.js

...
const currentProject = await getCurrentProject(2);
console.log('Proiectul curent pentru userul 2: ', currentProject);

const tasks = await getTasksByProjectId(currentProject.id);
console.log(`Proiectul current are task-urile: `, tasks);

const actions = await getTasksHistory(tasks.map(task => task.id));
console.log('History: ', actions);

```

- daca executam codul acum obtinem eroarea:

` SyntaxError: await is only valid in async function `


---

## Vom pune tot codul in interiorul unei functii prefixata cu `async`

```js
// app.js

async function getHistory() {                                               //+
    const currentProject = await getCurrentProject(2);
    console.log('Proiectul curent pentru userul 2: ', currentProject);
    
    const tasks = await getTasksByProjectId(currentProject.id);
    console.log(`Proiectul current are task-urile: `, tasks);
    
    const actions = await getTasksHistory(tasks.map(task => task.id));
    console.log('History: ', actions);
}
getHistory();                                                               //+

```

- acum la rularea `node app.js` vom avea acelasi rezultat ca inainte 
    - dar cu un cod similar cu codul sync


---

## Tratarea erorilor in patternul `async/await`

- adaugam bloc `try/catch`

```js
// app.js

async function getHistory() {
    try {                                                   //+
        const currentProject = await getCurrentProject(2);
        ...
        console.log('History: ', actions);
    } catch(err){                                           //+
        console.log('Eroare: ', err.message)                //+
    }                                                       //+
}
getHistory();

```

- acum daca rejectam una din promisiuni eroarea este tratata 
    - si afisata in consola


```js
// app.js

function getCurrentProject(userid) {
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            ...
            // resolve({ id: 1, name: 'Project One', userid: userid})   //~
            reject(new Error('Eroare getCurrentProject'))               //+
        }, 1500);
    })
}

```

- rezultatul in consola:

```
Running query...
Eroare:  Eroare getCurrentProject
```


---
