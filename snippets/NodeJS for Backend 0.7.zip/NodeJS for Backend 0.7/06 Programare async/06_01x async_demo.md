
# 05_01x async_demo

---

## cod sync combinat cu cod async

- prima data punem timp de asteptare 1500

- apoi punem zero (observam ca `DOI` apare tot ultimul)

```js
// app.js


console.log('Mesaj UNU');

// 1 -----------------
// setTimeout(()=>{
    //     console.log('Mesaj DOI (setTimeout)');
    // }, 1500)
    
// 2 -----------------
// chiar si cu asteptare 0, codul este trimis in coada
// si va fi nevoit sa astepte ca Thread-ul aplicatiei sa se elibereze
setTimeout(()=>{
    console.log('Mesaj DOI (setTimeout)');
}, 0)

console.log('Mesaj TREI');


```

