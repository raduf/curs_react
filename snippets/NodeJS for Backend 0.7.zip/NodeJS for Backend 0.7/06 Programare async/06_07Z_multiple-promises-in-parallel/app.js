
const promise1 = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('Query database one...');
        resolve({id: 1, name: 'Project One'})
    }, +(Math.random()*2000).toFixed(0) )
});

const promise2 = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('Query database two...');
        resolve({id: 2, name: 'Project Two'})
    }, +(Math.random()*2000).toFixed(0) )
});


const promise3 = new Promise((resolve, reject) => {
    setTimeout(() => {
        console.log('Query database three...');
        reject(new Error('Project three not found...'))
    }, +(Math.random()*2000).toFixed(0) )
});


// 1 Toate promisiunile trebuiesc rezolvate inainte de a primi rezultatele
// Promise.all([promise1, promise2])
//     .then( result => console.log('All resolved: ', result) )
//     .catch( err => console.log('All resolved - Eroare: ', err));

// 2 Avem o promisiune Rejected
// Promise.all([promise1, promise3])
//     .then( result => console.log('All resolved (una este rejected): ', result) )
//     .catch( err => console.log('All resolved (una este rejected)- Eroare: ', err));

// 3 Ne intereseaza prima promisiune rezolvata
// Promise.race([promise1, promise2])
//     .then( result => console.log('Prima rezolvata: ', result) )
//     .catch( err => console.log('Prima rezolvata - Eroare: ', err));


// 3 Ne intereseaza prima promisiune rezolvata - una este Rejected
Promise.race([promise1, promise3])
    .then( result => console.log('Prima rezolvata (una este rejected): ', result) )
    .catch( err => console.log('Prima rezolvata (una este rejected) - Eroare: ', err));

