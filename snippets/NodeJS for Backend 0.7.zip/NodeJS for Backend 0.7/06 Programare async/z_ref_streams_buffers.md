
https://docs.nodejitsu.com/articles/advanced/buffers/how-to-use-buffers/

