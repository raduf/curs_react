###### _Material Curs: NodeJS for REST API Backend - Daniel Turcu_
---

## What are Callbacks?

Callbacks are the name of a convention for using JavaScript functions. Instead of immediately returning some result like most functions, functions that use callbacks can take some time to produce a result. The syntax of a callback function may appear as to be:

```javascript
function callback(error, payload) {
  if (error) {
    console.error(error);
  } else {
    // payload data
  }
}
```

Since the function is going to be asynchronous, there is a possibility that due some reason, the operation might not complete. This error clause in our callback function will help us know.

Now, lets see when you run a normal function:

```javascript
const result = addTwoNumbers(3, 8);
console.log(result);
// 10 gets printed
```

However, functions that are asynchronous and use callbacks don't return anything when they are used.

```javascript
let file = downloadFile('http://abcdef.com/bookslist.pdf');
// file is 'undefined'!
```

Loading a file such as in above case can take a significant amount of time. If the function we are executing is synchronous, the application will be blocked till the file is download. If we make this function asynchronous, we can benefit from it. To avoid blocking I/O we must execute this function after the download is complete. We attach a callback function to the existing function to make it asynchronous. Since it is a going to download the file from a network, there might be a possibility that the network might not be working. We must make use of `error` argument in the callback function.

```javascript
function handleFileDownloading(error, file) {
  if (error) {
    console.error('Network error!');
  } else {
    console.log('Download Finished');
  }
}

downloadFile('http://abcdef.com/bookslist.pdf', handleFileDownloading);

console.log('Download Started');
```

To understand callbacks, we have to have a clear understanding of the order of execution works in these cases of asynchronous functions. In the above code snippet, we are first declaring the `handleFileDownloading` function. Then the `downloadFile` function is invoked which in turn calls `handleFileDownloading` function. Finally, the console statement that prints `Download Started` is executed. Note that the `handleFileDownloading` function is not invoked yet. Since it is an asynchronous function, it will execute only in two cases:

* either we get an error
* or the file is completely downloaded and then in return the console statement `Download Finished` will be returned

However, you may ask, the console statement `Download Finished` is declared before the `Download Started`, yet the vice versa is happening. It is because the console statements in JavaScript language are synchronous and they will get executed as soon as they are invoked. But since our `Download Finished` console statement is inside the callback function, it will only execute when the callback function is invoked. The order in which things happen or declared is not top-to-bottom in asynchronous programming.

### Callback Hell

When you use callbacks in your Node.js applications, you are going to run into something like this:

```javascript
fs.readdir(source, function(err, files) {
  if (err) {
    console.log('Error finding files: ' + err);
  } else {
    files.forEach(function(filename, fileIndex) {
      console.log(filename);
      gm(source + filename).size(function(err, values) {
        if (err) {
          console.log('Error identifying file size: ' + err);
        } else {
          console.log(filename + ' : ' + values);
          aspect = values.width / values.height;
          widths.forEach(
            function(width, widthIndex) {
              height = Math.round(width / aspect);
              console.log(
                'resizing ' + filename + 'to ' + height + 'x' + height
              );
              this.resize(width, height).write(
                dest + 'w' + width + '_' + filename,
                function(err) {
                  if (err) console.log('Error writing file: ' + err);
                }
              );
            }.bind(this)
          );
        }
      });
    });
  }
});
```

This is known as _callback hell_. It is going to be in a pyramid shape which makes the source code not only hard to read but difficult to keep a track of the order of things to happen after a certain point. The reason callback hells exist is not that of callbacks but because developers are often tempted to write a program where execution happens visually from top to bottom.

What we did above in our file downloading example solves this problem of callback hell or callback chaining. If we keep our functions modularized and name instead of using anonymous functions, it will be easier for developers to understand the code as well as the flow of the whole code. Another advantage of using a modularized code is that it increases code reusability. Reusable callback functions can be associated as many times as needed.

### Other Ways to Avoid Callback Hells

Writing callbacks is writing asynchronous code in a Node.js application. There are other modern and efficient ways to achieve the same functionality as we did with a simple callback function.

**Promises**
They are a way to write async code that still appears as though it is executing in a top-down way.

**Generators**
Generators let you 'pause' individual functions without pausing the state of the whole program, which at the cost of slightly more complex to understand code lets your async code appear to execute in a top-down fashion.

**Async/Await**
Async/Await functions are a proposed ES7 feature that will further wrap generators and promises in a higher level syntax.

## Promises

A promise is an object that wraps an asynchronous operation and notifies when it’s done. This sounds exactly like callbacks, but the important differences are in the usage of Promises. Instead of providing a callback, a promise has its own methods which you call to tell the promise what will happen when it is successful or when it fails. The methods a promise provides are `then()` for when a successful result is available and `catch()` for when something an error occurs.

There are different libraries available in JavaScript for creating and implementing promises in our source code, however, they are also natively introduced in JavaScript API with ES6. The syntax of a typical promise function looks like this:

```javascript
asyncOperation(parameters)
  .then(result => {
    // Do something with the result
  })
  .catch(error => {
    // handle error here
  });
```

Notice, how `then()` and `catch()` functions are chained together. The semicolon to terminate the whole promise based function will be the last. The `then()` part of a promise based function can be chained together when needed. This is similar to nesting callback functions without getting the pyramid looking source code (aka _callback hell_).

For this example, we will be using `axios` a library to make `requests` to an API.

```javascript
axios.get('https://abc.com/')
  .then((response) => {
    // response is the result here for first request
    // after some operations, it makes another call to the API
    axios.get('https://abc.com/users)
  })
  .then((response) => {
    // this response is the result of second request
  })
  .catch((error) => {
    // handle error
  });
```

The flow of the above function is easy to read and follow along. Also, you get to handle the error part only once, that is using `catch()`. This is another advantage of promises over callback. In callback functions, the first parameter is going to be the `error` and you will be always handling them each time you introduce a nested callback function.

If you decide to omit `.catch()` in above example when running in Node.js, an automated warning can be seen in logs that starts with `UnhandledPromiseRejectionWarning`. Thus, you should always have `.catch()` in your promise based function.
