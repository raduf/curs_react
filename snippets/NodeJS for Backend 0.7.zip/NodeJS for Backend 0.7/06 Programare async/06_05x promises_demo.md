
# 05_05x promises_demo


---

## vom crea o promisiune

```js
// app.js


var projectPromise = new Promise((resolve, reject) => {

    setTimeout(() => {
        let result = !(+Math.random().toFixed(0));
        if (result) {
            resolve({ id: 1, name: 'Project One', userid: 100})
        } else {
            reject(new Error('Proiectul nu exista!'))
        }
    }, 1000)

});

projectPromise
    .then( result => console.log('Proiectul returnat: ', result) )
    .catch( err => console.log('Eroare: ', err) );



```

